package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Lifts the wielder (self) or suspends a target, then always restores normal movement. */
public final class LevitateEffect extends Effect {
    private final LivingEntity target;
    private final boolean self;
    private final int durationTicks;
    private final double height;
    private double goalY;

    public LevitateEffect(NexarionPlugin pl, Player owner, LivingEntity target, int durationTicks, double height) {
        super(pl, owner);
        this.target = target;
        this.self = target.equals(owner);
        this.durationTicks = durationTicks;
        this.height = height;
    }

    public boolean isSelf() {
        return self;
    }

    @Override
    public Ability ability() {
        return Ability.LEVITATE;
    }

    @Override
    protected void tick() {
        if (!target.isValid() || target.isDead() || !target.getWorld().equals(owner.getWorld())) {
            end();
            return;
        }
        if (t == 0) goalY = target.getLocation().getY() + height;
        if (t >= durationTicks) {
            end();
            return;
        }
        double dy = goalY - target.getLocation().getY();
        double vy = Math.max(-0.4, Math.min(0.5, dy * 0.2));
        if (target instanceof Player) vy += 0.0784; // counter vanilla gravity for players
        Grav.hold(plugin, target, vy, 0.6);
        if (t % 4 == 0) {
            Location base = target.getLocation();
            Fx.ring(base.clone().add(0, 0.1, 0), 0.9, 14, t * 0.3, Fx.LILAC, 1.0f);
            Fx.p(base.clone().add(0, 0.2, 0), Particle.END_ROD, 2, 0.3, 0.1, 0.3, 0.01);
        }
    }

    @Override
    protected void cleanup() {
        Grav.release(plugin, target);
        Fx.sound(target.getLocation(), "levitate", 0.5f, 0.7f);
    }
}
