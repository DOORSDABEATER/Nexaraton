package com.dragonempire.nexarion.effects;

import org.bukkit.entity.Entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class EffectManager {
    private final Map<UUID, List<Effect>> byOwner = new HashMap<>();
    private final Set<Entity> tracked = new HashSet<>();

    public void add(Effect e) {
        byOwner.computeIfAbsent(e.owner().getUniqueId(), k -> new ArrayList<>()).add(e);
    }

    public void remove(Effect e) {
        List<Effect> l = byOwner.get(e.owner().getUniqueId());
        if (l != null) {
            l.remove(e);
            if (l.isEmpty()) byOwner.remove(e.owner().getUniqueId());
        }
    }

    @SuppressWarnings("unchecked")
    public <T extends Effect> T find(java.util.UUID owner, Class<T> type) {
        List<Effect> l = byOwner.get(owner);
        if (l == null) return null;
        for (Effect e : l) if (type.isInstance(e) && !e.isEnded()) return (T) e;
        return null;
    }

    public void endAll(UUID owner) {
        List<Effect> l = byOwner.get(owner);
        if (l == null) return;
        for (Effect e : new ArrayList<>(l)) e.end();
    }

    public void endOnWorldChange(UUID owner) {
        List<Effect> l = byOwner.get(owner);
        if (l == null) return;
        for (Effect e : new ArrayList<>(l)) if (e.endsOnWorldChange()) e.end();
    }

    public void endAll() {
        for (List<Effect> l : new ArrayList<>(byOwner.values())) for (Effect e : new ArrayList<>(l)) e.end();
        byOwner.clear();
    }

    public int count() {
        int n = 0;
        for (List<Effect> l : byOwner.values()) n += l.size();
        return n;
    }

    public void track(Entity e) {
        tracked.add(e);
    }

    public void untrack(Entity e) {
        tracked.remove(e);
    }

    public void sweepTracked() {
        tracked.removeIf(e -> !e.isValid());
    }

    public void removeAllTracked() {
        for (Entity e : new ArrayList<>(tracked)) if (e.isValid()) e.remove();
        tracked.clear();
    }
}
