package com.dragonempire.nexarion.listeners;

import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.event.world.EntitiesUnloadEvent;

import java.util.UUID;

/** Guarantees that no effect outlives its owner and no entity keeps altered gravity. */
public final class SafetyListener implements Listener {
    private final NexarionPlugin pl;
    private final WeaponListener weapon;
    private final CombatListener combat;

    public SafetyListener(NexarionPlugin pl, WeaponListener weapon, CombatListener combat) {
        this.pl = pl;
        this.weapon = weapon;
        this.combat = combat;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        pl.effects().endAll(id);
        pl.cooldowns().clear(id);
        pl.essence().cleanup(id);
        pl.essence().save();
        pl.hud().remove(id);
        weapon.forget(id);
        combat.forget(id);
        p.resetPlayerTime();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        pl.effects().endAll(e.getEntity().getUniqueId());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        pl.effects().endOnWorldChange(e.getPlayer().getUniqueId());
        e.getPlayer().resetPlayerTime();
    }

    @EventHandler
    public void onUnload(EntitiesUnloadEvent e) {
        for (Entity en : e.getEntities()) {
            if (en instanceof LivingEntity le && pl.gravity().tracked(le.getUniqueId())) pl.gravity().release(le);
        }
    }

    @EventHandler
    public void onLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) pl.gravity().repairLoaded(en);
    }
}
