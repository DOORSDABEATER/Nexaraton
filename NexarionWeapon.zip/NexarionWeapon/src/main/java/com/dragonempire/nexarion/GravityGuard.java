package com.dragonempire.nexarion;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks every non-player entity whose gravity we disabled so it can always be restored,
 * including after chunk unloads and crashes (a persistent marker is stored on the entity).
 */
public final class GravityGuard {
    private final Map<UUID, Boolean> original = new HashMap<>();
    private final NamespacedKey marker;

    public GravityGuard(NexarionPlugin pl) {
        this.marker = new NamespacedKey(pl, "gravity_marker");
    }

    public void grab(LivingEntity e) {
        if (e instanceof Player) return;
        if (!original.containsKey(e.getUniqueId())) {
            boolean g = e.hasGravity();
            original.put(e.getUniqueId(), g);
            e.getPersistentDataContainer().set(marker, PersistentDataType.BYTE, (byte) (g ? 1 : 0));
        }
        e.setGravity(false);
    }

    public void release(LivingEntity e) {
        Boolean g = original.remove(e.getUniqueId());
        if (g != null) {
            e.setGravity(g);
            e.getPersistentDataContainer().remove(marker);
        }
    }

    public boolean tracked(UUID id) {
        return original.containsKey(id);
    }

    public void releaseUuid(UUID id) {
        Entity e = Bukkit.getEntity(id);
        if (e instanceof LivingEntity le) release(le);
        else original.remove(id);
    }

    public void releaseAll() {
        for (UUID id : new ArrayList<>(original.keySet())) releaseUuid(id);
    }

    /** Called when an entity loads: restores gravity left disabled by a crash or unload. */
    public void repairLoaded(Entity e) {
        if (!(e instanceof LivingEntity le)) return;
        Byte b = e.getPersistentDataContainer().get(marker, PersistentDataType.BYTE);
        if (b != null && !original.containsKey(e.getUniqueId())) {
            le.setGravity(b == 1);
            e.getPersistentDataContainer().remove(marker);
        }
    }
}
