package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Ray-marched projectile (no vanilla projectile entity), with optional spinning display model. */
public class Bolt extends Effect {
    public interface StepFn { void step(Bolt b, Location pos); }
    public interface EntityFn { void hit(Bolt b, LivingEntity e, Location pos); }
    public interface BlockFn { void hit(Bolt b, Location pos); }

    public final Location pos;
    public final Vector dir;
    private final double speed, range, radius;
    private int pierceLeft;
    private double traveled;
    private final Set<UUID> hitSet = new HashSet<>();

    public StepFn onStep;
    public EntityFn onEntity;
    public BlockFn onBlock;
    public Runnable onEnd;
    public ItemDisplay display;
    public float spin;
    public float displayScale = 1f;
    private float angle;

    public Bolt(NexarionPlugin pl, Player owner, Location start, Vector dir, double speed, double range, double radius, int pierce) {
        super(pl, owner);
        this.pos = start.clone();
        this.dir = dir.clone().normalize();
        this.speed = speed;
        this.range = range;
        this.radius = radius;
        this.pierceLeft = pierce;
    }

    @Override
    protected void tick() {
        World w = pos.getWorld();
        if (w == null) {
            end();
            return;
        }
        RayTraceResult br = w.rayTraceBlocks(pos, dir, speed, FluidCollisionMode.NEVER, true);
        double seg = br != null ? Math.max(0.0, br.getHitPosition().distance(pos.toVector())) : speed;
        int samples = (int) Math.max(1, Math.ceil(seg / 0.6));
        for (int i = 1; i <= samples; i++) {
            Location p = pos.clone().add(dir.clone().multiply(seg * i / samples));
            if (onStep != null) onStep.step(this, p);
            for (Entity en : w.getNearbyEntities(BoundingBox.of(p, radius, radius, radius))) {
                if (!(en instanceof LivingEntity le) || en.equals(owner) || hitSet.contains(en.getUniqueId())) continue;
                if (!Dmg.eligible(plugin, owner, le)) continue;
                hitSet.add(en.getUniqueId());
                if (onEntity != null) onEntity.hit(this, le, p);
                if (pierceLeft <= 0) {
                    pos.setX(p.getX());
                    pos.setY(p.getY());
                    pos.setZ(p.getZ());
                    finish();
                    return;
                }
                pierceLeft--;
            }
        }
        pos.add(dir.clone().multiply(seg));
        traveled += seg;
        updateDisplay();
        if (br != null) {
            if (onBlock != null) onBlock.hit(this, pos.clone());
            finish();
            return;
        }
        if (traveled >= range) finish();
    }

    private void updateDisplay() {
        if (display == null || !display.isValid()) return;
        Location l = pos.clone();
        l.setDirection(dir);
        display.teleport(l);
        if (spin != 0) {
            angle += spin;
            display.setInterpolationDelay(0);
            display.setInterpolationDuration(1);
            display.setTransformation(new Transformation(new Vector3f(), new Quaternionf().rotateZ(angle),
                    new Vector3f(displayScale, displayScale, displayScale), new Quaternionf()));
        }
    }

    public void finish() {
        if (isEnded()) return;
        try {
            if (onEnd != null) onEnd.run();
        } finally {
            end();
        }
    }

    @Override
    protected void cleanup() {
        Fx.removeDisplay(display);
        display = null;
    }
}
