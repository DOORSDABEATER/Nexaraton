package com.dragonempire.nexarion;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class Cooldowns {
    private final Map<UUID, EnumMap<Ability, Long>> map = new HashMap<>();

    public long remainingMs(UUID id, Ability a) {
        EnumMap<Ability, Long> m = map.get(id);
        if (m == null) return 0;
        Long end = m.get(a);
        if (end == null) return 0;
        long r = end - System.currentTimeMillis();
        if (r <= 0) {
            m.remove(a);
            return 0;
        }
        return r;
    }

    public boolean ready(UUID id, Ability a) {
        return remainingMs(id, a) <= 0;
    }

    public void set(UUID id, Ability a, long ms) {
        if (ms <= 0) return;
        map.computeIfAbsent(id, k -> new EnumMap<>(Ability.class)).put(a, System.currentTimeMillis() + ms);
    }

    public void clear(UUID id) {
        map.remove(id);
    }

    public void clear(UUID id, Ability a) {
        EnumMap<Ability, Long> m = map.get(id);
        if (m != null) m.remove(a);
    }
}
