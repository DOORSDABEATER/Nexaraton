package com.dragonempire.nexarion;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Config-driven input bindings with Dagger Submode priority. */
public final class Controls {
    public enum Input { SHIFT_LEFT_CLICK, SHIFT_RIGHT_CLICK, SHIFT_F, RIGHT_CLICK, F }

    /** Declaration order is the priority order when several actions share an input. */
    public enum Action { THROW_DAGGER, TOGGLE_DAGGER, SWITCH_FORM, CYCLE_ABILITY, ACTIVATE }

    private final NexarionPlugin pl;
    private final Map<Input, List<Action>> bind = new EnumMap<>(Input.class);

    public Controls(NexarionPlugin pl) {
        this.pl = pl;
        reload();
    }

    public void reload() {
        bind.clear();
        for (Action a : Action.values()) {
            String def = switch (a) {
                case THROW_DAGGER -> "SHIFT_LEFT_CLICK";
                case TOGGLE_DAGGER -> "SHIFT_F";
                case SWITCH_FORM -> "SHIFT_RIGHT_CLICK";
                case CYCLE_ABILITY -> "SHIFT_LEFT_CLICK";
                case ACTIVATE -> "RIGHT_CLICK";
            };
            String s = pl.getConfig().getString("controls." + a.name().toLowerCase(Locale.ROOT), def);
            Input in;
            try {
                in = Input.valueOf(s.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                pl.getLogger().warning("Invalid control binding '" + s + "' for " + a + ", using " + def);
                in = Input.valueOf(def);
            }
            bind.computeIfAbsent(in, k -> new ArrayList<>()).add(a);
        }
        for (List<Action> l : bind.values()) l.sort(null);
    }

    public Action resolve(Input in, Form form) {
        List<Action> l = bind.get(in);
        if (l == null) return null;
        for (Action a : l) {
            if (a == Action.THROW_DAGGER && form != Form.DAGGER) continue;
            if (a == Action.TOGGLE_DAGGER && form == Form.STAFF) continue;
            return a;
        }
        return null;
    }
}
