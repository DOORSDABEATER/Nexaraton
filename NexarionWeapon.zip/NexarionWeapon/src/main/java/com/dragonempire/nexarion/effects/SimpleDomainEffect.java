package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Defensive sword-counter domain: incoming hostile attacks are intercepted and answered with a counter slash. */
public final class SimpleDomainEffect extends Effect {
    private final double radius;
    private final int durationRuns; // period is 2 ticks
    private final double counterDamage;
    private final double counterRange;
    private final Map<UUID, Integer> lastCounter = new HashMap<>();

    public SimpleDomainEffect(NexarionPlugin pl, Player owner) {
        super(pl, owner);
        var c = pl.getConfig();
        this.radius = c.getDouble("abilities.simple_domain.radius", 3.2);
        this.durationRuns = (int) Math.max(5, c.getDouble("abilities.simple_domain.duration", 6.0) * 10);
        this.counterDamage = c.getDouble("abilities.simple_domain.counter-damage", 8.0);
        this.counterRange = c.getDouble("abilities.simple_domain.counter-range", 6.0);
    }

    @Override
    public Ability ability() {
        return Ability.SIMPLE_DOMAIN;
    }

    /**
     * Called from the damage listener. Returns true if the incoming hit was absorbed (the event should be cancelled).
     */
    public boolean absorb(Entity source, LivingEntity attacker) {
        if (isEnded() || t < 2) return false;
        if (source instanceof Projectile proj) {
            if (attacker != null && !Dmg.isThreat(owner, attacker)) return false;
            proj.remove();
        } else if (attacker == null || !Dmg.isThreat(owner, attacker)) {
            return false;
        }
        if (attacker != null && attacker.getLocation().distance(owner.getLocation()) <= counterRange) counter(attacker);
        return true;
    }

    private void counter(LivingEntity attacker) {
        int now = Bukkit.getCurrentTick();
        Integer last = lastCounter.get(attacker.getUniqueId());
        if (last != null && now - last < 10) return;
        lastCounter.put(attacker.getUniqueId(), now);
        Location from = owner.getLocation().add(0, 1.2, 0);
        Location to = attacker.getLocation().add(0, attacker.getHeight() * 0.6, 0);
        Vector dir = to.toVector().subtract(from.toVector());
        if (dir.lengthSquared() < 0.01) dir = owner.getLocation().getDirection();
        dir.normalize();
        if (Dmg.hit(plugin, owner, attacker, counterDamage, "simple_domain")) {
            attacker.setVelocity(attacker.getVelocity().add(dir.clone().multiply(0.7).setY(0.25)));
        }
        Fx.line(from, to, Fx.WHITE, 1.1f, 0.35);
        Fx.line(from.clone().add(0, 0.4, 0), to.clone().add(0, -0.3, 0), Fx.LILAC, 0.9f, 0.4);
        Fx.p(to, Particle.SWEEP_ATTACK, 1, 0, 0, 0, 0);
        Fx.p(to, Particle.CRIT, 12, 0.3, 0.3, 0.3, 0.2);
        Fx.slashDisplay(to, dir, (float) (Math.random() * Math.PI), 2.4f, 5);
        Fx.sound(to, "simple_domain_counter", 1f, 1f + (float) Math.random() * 0.2f);
    }

    @Override
    protected void tick() {
        if (t == 0) {
            Fx.sound(owner.getLocation(), "simple_domain", 1f, 1f);
            plugin.hud().flash(owner, "<white>⚔ Simple Domain <gray>- hostile strikes will be countered");
        }
        if (t >= durationRuns) {
            end();
            return;
        }
        Location c = owner.getLocation().add(0, 0.08, 0);
        double grow = Math.min(1.0, t / 6.0); // activation animation: ring expands outward
        double r = radius * grow;
        double rot = t * 0.22;
        Fx.ring(c, r, 36, rot, Fx.WHITE, 0.9f);
        Fx.ring(c, r * 0.62, 24, -rot * 1.4, Fx.LILAC, 0.8f);
        for (int i = 0; i < 8; i++) {
            double a = rot + i * Math.PI / 4;
            Location p = c.clone().add(Math.cos(a) * r * 0.62, 0, Math.sin(a) * r * 0.62);
            Location q = c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r);
            Fx.line(p, q, Fx.VIOLET, 0.7f, 0.5);
        }
        if (t % 3 == 0) {
            Fx.ring(c.clone().add(0, 1.0, 0), r * 0.9, 18, -rot, Fx.WHITE, 0.6f);
            Fx.p(owner.getLocation().add(0, 1, 0), Particle.ENCHANTED_HIT, 3, 0.6, 0.8, 0.6, 0.05);
        }
    }

    @Override
    protected void cleanup() {
        lastCounter.clear();
        Fx.sound(owner.getLocation(), "infinity_off", 0.5f, 1.4f);
    }
}
