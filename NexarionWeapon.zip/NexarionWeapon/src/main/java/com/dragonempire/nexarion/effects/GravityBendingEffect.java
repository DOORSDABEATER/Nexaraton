package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.Msg;
import com.dragonempire.nexarion.NexarionPlugin;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Ultimate: Gravity Bending. A gravity field lasting EXACTLY 60 seconds (1200 ticks). The wielder re-casts
 * (right click) to cycle the field's vertical mode: Float, Lift, Descend, Pin.
 */
public final class GravityBendingEffect extends Effect {
    public static final int DURATION_TICKS = 1200;

    public enum Mode {
        FLOAT("Float", Fx.CYAN),
        LIFT("Lift", Fx.GOLD),
        DESCEND("Descend", Fx.VIOLET),
        PIN("Pin", Fx.CRIMSON);

        public final String label;
        public final Color color;

        Mode(String label, Color color) {
            this.label = label;
            this.color = color;
        }
    }

    private final World world;
    private final Location center;
    private final double radius, vRadius, ceilingY, pinDamage;
    private final boolean affectOwner;
    private final Boolean affectPassive;
    private final Set<UUID> affected = new HashSet<>();
    private Mode mode = Mode.FLOAT;

    public GravityBendingEffect(NexarionPlugin pl, Player owner, Location center) {
        super(pl, owner);
        var c = pl.getConfig();
        this.world = center.getWorld();
        this.center = center.clone();
        this.radius = Math.min(40.0, Math.max(4.0, c.getDouble("abilities.gravity_bending.radius", 15.0)));
        this.vRadius = Math.min(40.0, Math.max(4.0, c.getDouble("abilities.gravity_bending.vertical-radius", 18.0)));
        this.ceilingY = center.getY() + Math.max(4.0, c.getDouble("abilities.gravity_bending.ceiling-height", 14.0));
        this.pinDamage = Math.max(0.0, c.getDouble("abilities.gravity_bending.pin-damage", 1.0));
        this.affectOwner = c.getBoolean("abilities.gravity_bending.affect-owner", true);
        this.affectPassive = c.getBoolean("abilities.gravity_bending.affect-passive-mobs", true);
    }

    @Override
    public Ability ability() {
        return Ability.GRAVITY_BENDING;
    }

    public Mode mode() {
        return mode;
    }

    public int secondsLeft() {
        return Math.max(0, (DURATION_TICKS - t + 19) / 20);
    }

    public void nextMode() {
        mode = Mode.values()[(mode.ordinal() + 1) % Mode.values().length];
        Fx.sound(owner.getLocation(), "gravity_pulse", 1f, 0.8f + mode.ordinal() * 0.2f);
        plugin.hud().flash(owner, "<light_purple>Gravity: <white>" + mode.label);
        Fx.ring(center.clone().add(0, 0.3, 0), radius, 70, 0, mode.color, 1.6f);
    }

    @Override
    protected void tick() {
        if (t == 0) intro();
        if (t >= DURATION_TICKS) {
            end();
            return;
        }
        if (!owner.getWorld().equals(world)) {
            end();
            return;
        }
        if (t % 5 == 0) rescan();
        applyMode();
        if (mode == Mode.PIN && pinDamage > 0 && t % 20 == 0) pinDamageTick();
        if (t % 2 == 0) visuals();
        if (t > 0 && t % 60 == 0) {
            Fx.sound(center, "gravity_pulse", 2f, 1f);
            Fx.ring(center.clone().add(0, 0.3, 0), radius, 80, 0, Fx.WHITE, 1.4f);
        }
    }

    private void intro() {
        Fx.sound(center, "gravity_bending", 3f, 1f);
        plugin.hud().flash(owner, "<light_purple>Gravity Bending <gray>- 60s · right click to change mode");
        Title title = Title.title(
                Msg.c("<gradient:#4de1ff:#7b2cff><b>GRAVITY BENDING</b></gradient>"),
                Msg.c("<gray>The ground forgets its weight"),
                Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1800), Duration.ofMillis(500)));
        for (Player p : world.getPlayers()) {
            if (p.getLocation().distanceSquared(center) <= radius * radius) p.showTitle(title);
        }
        Fx.p(center.clone().add(0, 1, 0), Particle.REVERSE_PORTAL, 120, radius * 0.4, 1.5, radius * 0.4, 0.5);
    }

    private void rescan() {
        Set<UUID> now = new HashSet<>();
        for (Entity e : world.getNearbyEntities(center, radius, vRadius, radius)) {
            if (!(e instanceof LivingEntity le) || !le.isValid() || le.isDead()) continue;
            double dx = le.getX() - center.getX(), dz = le.getZ() - center.getZ();
            if (dx * dx + dz * dz > radius * radius) continue;
            if (e.equals(owner)) {
                if (affectOwner) now.add(e.getUniqueId());
                continue;
            }
            if (!Dmg.controllable(plugin, owner, e, affectPassive)) continue;
            now.add(e.getUniqueId());
        }
        for (UUID id : affected) if (!now.contains(id)) releaseId(id);
        affected.clear();
        affected.addAll(now);
    }

    private void applyMode() {
        for (UUID id : affected) {
            Entity e = Bukkit.getEntity(id);
            if (!(e instanceof LivingEntity le) || !le.isValid() || !le.getWorld().equals(world)) continue;
            boolean isOwner = le.equals(owner);
            double y = le.getLocation().getY();
            double comp = le instanceof Player ? 0.0784 : 0.0;
            switch (mode) {
                case FLOAT -> Grav.hold(plugin, le, (y < ceilingY ? 0.035 : 0.0) + comp, 0.92);
                case LIFT -> Grav.hold(plugin, le, (y < ceilingY ? 0.2 : 0.0) + comp, 0.95);
                case DESCEND -> Grav.hold(plugin, le, (le.isOnGround() ? 0.0 : -0.12) + comp, 0.95);
                case PIN -> {
                    if (isOwner) Grav.hold(plugin, le, comp, 0.95);
                    else Grav.pin(plugin, le);
                }
            }
        }
    }

    private void pinDamageTick() {
        for (UUID id : new HashSet<>(affected)) {
            Entity e = Bukkit.getEntity(id);
            if (e instanceof LivingEntity le && !le.equals(owner)) Dmg.hit(plugin, owner, le, pinDamage, "gravity_bending");
        }
    }

    private void visuals() {
        double h = ceilingY - center.getY();
        double rot = t * 0.03;
        Color col = mode.color;
        if (t < 20) {
            Fx.ring(center.clone().add(0, 0.3, 0), radius * (t / 20.0), 60, rot, Fx.WHITE, 1.6f);
        }
        Fx.ring(center.clone().add(0, 0.3, 0), radius, 48, rot, col, 1.3f);
        Fx.ring(center.clone().add(0, 0.3, 0), radius * 0.5, 24, -rot * 2, Fx.LILAC, 1.0f);
        Fx.ring(center.clone().add(0, h * 0.5, 0), radius * 0.9, 40, -rot, Fx.VIOLET, 1.0f);
        boolean up = mode == Mode.FLOAT || mode == Mode.LIFT;
        for (int i = 0; i < 8; i++) {
            double a = rot * 6 + i * Math.PI / 4;
            double f = ((t * 0.25 + i * 2.0) % h) / h;
            double yy = up ? f * h : (1 - f) * h;
            Location p = center.clone().add(Math.cos(a) * radius * 0.8, yy, Math.sin(a) * radius * 0.8);
            Fx.dust(p, col, 1.2f, 1, 0.05);
            if (i % 3 == 0) Fx.p(p, Particle.REVERSE_PORTAL, 1, 0.1, 0.1, 0.1, 0.1);
        }
    }

    private void releaseId(UUID id) {
        Entity e = Bukkit.getEntity(id);
        if (e instanceof LivingEntity le) Grav.release(plugin, le);
        else plugin.gravity().releaseUuid(id);
    }

    @Override
    protected void cleanup() {
        for (UUID id : new HashSet<>(affected)) releaseId(id);
        affected.clear();
        Grav.release(plugin, owner); // the wielder is always restored, even if not in the set
        Fx.sound(center, "gravity_bending", 2f, 0.6f);
        Fx.ring(center.clone().add(0, 0.3, 0), radius, 80, 0, Fx.WHITE, 1.6f);
    }
}
