package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/**
 * Vertical-movement control used by Levitate and Gravity Bending. Every potion effect applied here is very
 * short (12 ticks) and refreshed, so nothing can stay permanently even if a cleanup were somehow missed.
 */
public final class Grav {
    private static final int SHORT = 12;

    private Grav() {}

    /** Hover (or move vertically) at vertical velocity vy. */
    public static void hold(NexarionPlugin pl, LivingEntity e, double vy, double horizontalDamp) {
        Vector v = e.getVelocity();
        if (e instanceof Player) {
            // The levitation effect also keeps vanilla's anti-fly kick from triggering.
            e.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, SHORT, 0, true, false, false));
            e.setVelocity(new Vector(v.getX(), vy, v.getZ()));
        } else {
            pl.gravity().grab(e);
            e.setVelocity(new Vector(v.getX() * horizontalDamp, vy, v.getZ() * horizontalDamp));
        }
        e.setFallDistance(0f);
    }

    /** Press the entity to the ground and slow it. */
    public static void pin(NexarionPlugin pl, LivingEntity e) {
        pl.gravity().release(e);
        e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, SHORT, 2, true, false, false));
        Vector v = e.getVelocity();
        e.setVelocity(new Vector(v.getX() * 0.4, e.isOnGround() ? -0.1 : -0.9, v.getZ() * 0.4));
        e.setFallDistance(0f);
    }

    /** Restore normal movement. Safe to call repeatedly. */
    public static void release(NexarionPlugin pl, LivingEntity e) {
        if (e == null) return;
        pl.gravity().release(e);
        PotionEffect lev = e.getPotionEffect(PotionEffectType.LEVITATION);
        if (lev != null && lev.getAmplifier() == 0 && lev.getDuration() <= SHORT) e.removePotionEffect(PotionEffectType.LEVITATION);
        PotionEffect slow = e.getPotionEffect(PotionEffectType.SLOWNESS);
        if (slow != null && slow.getAmplifier() == 2 && slow.getDuration() <= SHORT) e.removePotionEffect(PotionEffectType.SLOWNESS);
        e.setFallDistance(0f);
        if (e instanceof Player) {
            e.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 100, 0, true, false, true));
        }
    }
}
