package com.dragonempire.nexarion;

import java.util.List;
import java.util.Locale;

public enum Form {
    STAFF("Staff", "staff"),
    SWORD("Sword", "sword"),
    DAGGER("Daggers", "dagger");

    public final String display;
    public final String model;

    Form(String display, String model) {
        this.display = display;
        this.model = model;
    }

    public List<Ability> abilities() {
        return switch (this) {
            case STAFF -> List.of(Ability.AIR_SLASH, Ability.FIREBALL, Ability.LEVITATE, Ability.SIMPLE_DOMAIN,
                    Ability.INFINITY, Ability.DOMAIN_EXPANSION, Ability.GRAVITY_BENDING);
            case SWORD, DAGGER -> List.of(Ability.AIR_SLASH);
        };
    }

    public static Form parse(String s) {
        if (s == null) return null;
        try {
            return valueOf(s.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
