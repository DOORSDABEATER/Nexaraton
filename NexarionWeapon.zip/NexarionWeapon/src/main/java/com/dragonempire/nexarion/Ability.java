package com.dragonempire.nexarion;

import java.util.Locale;

public enum Ability {
    AIR_SLASH("Air Slash", false, true),
    FIREBALL("Fireball", false, true),
    LEVITATE("Levitate", false, true),
    SIMPLE_DOMAIN("Simple Domain", false, true),
    INFINITY("Infinity", false, true),
    DOMAIN_EXPANSION("Domain Expansion", true, true),
    GRAVITY_BENDING("Gravity Bending", true, true),
    DAGGER_THROW("Dagger Throw", false, false);

    public final String display;
    public final boolean ultimate;
    public final boolean selectable;

    Ability(String display, boolean ultimate, boolean selectable) {
        this.display = display;
        this.ultimate = ultimate;
        this.selectable = selectable;
    }

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static Ability parse(String s) {
        if (s == null) return null;
        String n = s.toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        for (Ability a : values()) if (a.name().equals(n)) return a;
        return null;
    }
}
