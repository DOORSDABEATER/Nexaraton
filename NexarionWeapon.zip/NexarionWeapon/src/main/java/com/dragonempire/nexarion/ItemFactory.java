package com.dragonempire.nexarion;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

/**
 * Creates and validates NEXARION items. Identity is a signed persistent-data tag, so renaming
 * or re-lore-ing an ordinary item can never produce a valid NEXARION.
 */
public final class ItemFactory {
    private final NexarionPlugin pl;
    public final NamespacedKey kId, kSig, kForm, kSel;
    private final NamespacedKey kDmg, kSpd;
    private final byte[] secret;

    public ItemFactory(NexarionPlugin pl) {
        this.pl = pl;
        this.kId = new NamespacedKey(pl, "weapon_id");
        this.kSig = new NamespacedKey(pl, "weapon_sig");
        this.kForm = new NamespacedKey(pl, "form");
        this.kSel = new NamespacedKey(pl, "selected");
        this.kDmg = new NamespacedKey(pl, "attack_damage");
        this.kSpd = new NamespacedKey(pl, "attack_speed");
        this.secret = loadSecret();
    }

    private byte[] loadSecret() {
        File f = new File(pl.getDataFolder(), "secret.key");
        try {
            if (f.exists()) {
                String s = Files.readString(f.toPath()).trim();
                if (s.length() >= 32) return s.getBytes(StandardCharsets.UTF_8);
            }
            byte[] r = new byte[32];
            new SecureRandom().nextBytes(r);
            String hex = HexFormat.of().formatHex(r);
            pl.getDataFolder().mkdirs();
            Files.writeString(f.toPath(), hex);
            return hex.getBytes(StandardCharsets.UTF_8);
        } catch (IOException e) {
            pl.getLogger().warning("Could not read/write secret.key: " + e.getMessage());
            return "nexarion-fallback-secret-please-fix-file-permissions".getBytes(StandardCharsets.UTF_8);
        }
    }

    private String sign(String id) {
        try {
            Mac m = Mac.getInstance("HmacSHA256");
            m.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(m.doFinal(id.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public ItemStack create(Form form) {
        ItemStack it = new ItemStack(Material.NETHERITE_SWORD);
        apply(it, form, 0);
        return it;
    }

    public boolean isNexarion(ItemStack it) {
        if (it == null || it.getType() != Material.NETHERITE_SWORD || !it.hasItemMeta()) return false;
        PersistentDataContainer pdc = it.getItemMeta().getPersistentDataContainer();
        String id = pdc.get(kId, PersistentDataType.STRING);
        String sig = pdc.get(kSig, PersistentDataType.STRING);
        return id != null && sig != null && sig.equals(sign(id));
    }

    public Form form(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return Form.STAFF;
        String s = it.getItemMeta().getPersistentDataContainer().get(kForm, PersistentDataType.STRING);
        Form f = Form.parse(s);
        return f == null ? Form.STAFF : f;
    }

    public int selected(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return 0;
        Integer i = it.getItemMeta().getPersistentDataContainer().get(kSel, PersistentDataType.INTEGER);
        return i == null ? 0 : i;
    }

    public void setSelected(ItemStack it, int sel) {
        ItemMeta m = it.getItemMeta();
        m.getPersistentDataContainer().set(kSel, PersistentDataType.INTEGER, sel);
        it.setItemMeta(m);
    }

    /** Applies form appearance, stats and identity to the item (keeps an existing identity). */
    public void apply(ItemStack it, Form f, int sel) {
        ItemMeta m = it.getItemMeta();
        PersistentDataContainer pdc = m.getPersistentDataContainer();
        String id = pdc.get(kId, PersistentDataType.STRING);
        if (id == null) id = "nexarion:" + UUID.randomUUID();
        pdc.set(kId, PersistentDataType.STRING, id);
        pdc.set(kSig, PersistentDataType.STRING, sign(id));
        pdc.set(kForm, PersistentDataType.STRING, f.name());
        pdc.set(kSel, PersistentDataType.INTEGER, sel);

        String color = switch (f) {
            case STAFF -> "<gradient:#8a5cff:#d9b8ff>";
            case SWORD -> "<gradient:#ffd24d:#ff9f1c>";
            case DAGGER -> "<gradient:#ff4d6d:#ffb3c1>";
        };
        String end = "</gradient>";
        m.displayName(Msg.c("<!italic><b>" + color + "NEXARION" + end + "</b> <dark_gray>- <gray>" + f.display));

        List<Component> lore = new ArrayList<>();
        lore.add(Msg.c("<!italic><gradient:#8a5cff:#ffd24d>Legendary · The Boundless Sovereign</gradient>"));
        lore.add(Component.empty());
        switch (f) {
            case STAFF -> {
                lore.add(Msg.c("<!italic><gray>Abilities:"));
                for (Ability a : f.abilities()) {
                    lore.add(Msg.c("<!italic>" + (a.ultimate ? "<gold>★ " : "<light_purple>◆ ") + "<white>" + a.display));
                }
            }
            case SWORD -> {
                lore.add(Msg.c("<!italic><gray>Sovereign Edge: every few hits unleash a finisher."));
                lore.add(Msg.c("<!italic><light_purple>◆ <white>Air Slash"));
                lore.add(Msg.c("<!italic><dark_gray>Shift + F: Dagger Submode"));
            }
            case DAGGER -> {
                lore.add(Msg.c("<!italic><gray>Twin Fangs: blistering attack speed."));
                lore.add(Msg.c("<!italic><light_purple>◆ <white>Air Slash"));
                lore.add(Msg.c("<!italic><red>⚔ <white>Shift + Left Click: Throw Daggers"));
            }
        }
        lore.add(Component.empty());
        lore.add(Msg.c("<!italic><dark_gray>Bound to the Dragon Empire."));
        m.lore(lore);

        m.setUnbreakable(true);
        m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
        m.setEnchantmentGlintOverride(true);
        m.setItemModel(NamespacedKey.fromString("nexarion:" + f.model));

        FileConfiguration c = pl.getConfig();
        String p = "forms." + f.name().toLowerCase() + ".";
        m.removeAttributeModifier(Attribute.ATTACK_DAMAGE);
        m.removeAttributeModifier(Attribute.ATTACK_SPEED);
        m.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(kDmg,
                c.getDouble(p + "attack-damage", 6.0), AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        m.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(kSpd,
                c.getDouble(p + "attack-speed", -2.4), AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        it.setItemMeta(m);
    }
}
