package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.Msg;
import com.dragonempire.nexarion.NexarionPlugin;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Ultimate: "Sovereign's Dominion - Throne of Ten Thousand Cuts".
 * Client-side terrain transformation (no real block changes), a rising BlockDisplay shrine, night sky,
 * continuous slashes, and a collapse finale. Everything is restored in cleanup().
 */
public final class DomainExpansionEffect extends Effect {
    private static final int SEQUENCE_RUNS = 20;   // 40 ticks of activation sequence
    private static final int WIND_RUNS = 12;       // 24 ticks of ending animation
    private static final int MAX_BLOCKS = 6500;

    private final World world;
    private final Location center;
    private final double radius;
    private final int activeRuns;
    private final double slashDamage;
    private final int pulseEvery;
    private final int maxTargets;
    private final Random rng = new Random();

    private final List<BlockDisplay> shrine = new ArrayList<>();
    private int[] bx = new int[0], by = new int[0], bz = new int[0];
    private BlockData[] bdata = new BlockData[0];
    private int blockCount;
    private final Set<UUID> viewers = new HashSet<>();
    private final Set<UUID> nightSet = new HashSet<>();
    private boolean restored;
    private boolean winding;
    private int windStart;

    public DomainExpansionEffect(NexarionPlugin pl, Player owner) {
        super(pl, owner);
        var c = pl.getConfig();
        this.world = owner.getWorld();
        this.center = owner.getLocation().clone();
        this.radius = Math.min(40.0, Math.max(6.0, c.getDouble("abilities.domain_expansion.radius", 18.0)));
        double secs = Math.min(60.0, Math.max(3.0, c.getDouble("abilities.domain_expansion.duration", 20.0)));
        this.activeRuns = (int) (secs * 10);
        this.slashDamage = c.getDouble("abilities.domain_expansion.slash-damage", 5.0);
        this.pulseEvery = Math.max(1, c.getInt("abilities.domain_expansion.slash-interval-ticks", 8) / 2);
        this.maxTargets = Math.max(1, c.getInt("abilities.domain_expansion.max-targets-per-pulse", 16));
    }

    @Override
    public Ability ability() {
        return Ability.DOMAIN_EXPANSION;
    }

    public int secondsLeft() {
        return winding ? 0 : Math.max(0, (SEQUENCE_RUNS + activeRuns - t) / 10);
    }

    @Override
    protected void tick() {
        if (t == 0) begin();
        if (!winding) {
            if (t < SEQUENCE_RUNS) sequence();
            else if ((t - SEQUENCE_RUNS) % pulseEvery == 0) pulse();
            if (t % 10 == 0) refreshViewers();
            if (t % 5 == 0) updateNight();
            ambientFx();
            if (t >= SEQUENCE_RUNS + activeRuns) startWinding();
        } else {
            windStep();
            if (t >= windStart + WIND_RUNS) end();
        }
    }

    // ------------------------------------------------------------ start / end

    private void begin() {
        Fx.sound(center, "domain_expansion", 4f, 1f);
        buildBlocks();
        buildShrine();
        for (Player p : playersNear(radius + 16)) {
            sendBlocks(p, true);
            viewers.add(p.getUniqueId());
        }
        Title title = Title.title(
                Msg.c("<gradient:#d81b3c:#ffd24d><b>DOMAIN EXPANSION</b></gradient>"),
                Msg.c("<gray>Sovereign's Dominion: <white>Throne of Ten Thousand Cuts"),
                Title.Times.times(Duration.ofMillis(300), Duration.ofMillis(2400), Duration.ofMillis(700)));
        for (Player p : playersNear(radius)) p.showTitle(title);
    }

    private void startWinding() {
        winding = true;
        windStart = t;
        restoreAll();
        Fx.sound(center, "domain_end", 4f, 0.9f);
        Fx.p(center.clone().add(0, 2, 0), Particle.EXPLOSION_EMITTER, 1, 0, 0, 0, 0);
        Fx.p(center.clone().add(0, 3, 0), Particle.END_ROD, 80, 4, 3, 4, 0.2);
        for (BlockDisplay d : shrine) {
            if (!d.isValid()) continue;
            d.setInterpolationDelay(0);
            d.setInterpolationDuration(WIND_RUNS * 2);
            d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.01f, 0.01f, 0.01f), new Quaternionf()));
        }
        for (Player p : playersNear(radius)) {
            p.sendActionBar(Msg.c("<gray>The dominion <gold>shatters<gray>."));
        }
    }

    private void windStep() {
        double k = Math.min(1.0, (t - windStart) / (double) WIND_RUNS);
        Location c = center.clone().add(0, 0.3, 0);
        Fx.ring(c, radius * k, (int) (radius * 5 + 20), 0, Fx.GOLD, 1.6f);
        Fx.ring(c.clone().add(0, 0.5, 0), radius * k * 0.85, (int) (radius * 4 + 16), 0, Fx.WHITE, 1.2f);
        Fx.p(c.clone().add(rng.nextGaussian() * 3, 2 + rng.nextDouble() * 6, rng.nextGaussian() * 3), Particle.CRIT, 20, 1, 1, 1, 0.4);
    }

    @Override
    protected void cleanup() {
        restoreAll();
        for (BlockDisplay d : shrine) Fx.removeDisplay(d);
        shrine.clear();
    }

    // ---------------------------------------------------------- activation FX

    private void sequence() {
        double k = (t + 1) / (double) SEQUENCE_RUNS;
        double r = radius * k;
        Location c = center.clone().add(0, 0.25, 0);
        Fx.ring(c, r, (int) (r * 6 + 12), t * 0.35, Fx.CRIMSON, 1.5f);
        Fx.ring(c, r * 0.8, (int) (r * 5 + 10), -t * 0.4, Fx.GOLD, 1.2f);
        for (int i = 0; i < 6; i++) {
            double a = rng.nextDouble() * Math.PI * 2;
            Location p = c.clone().add(Math.cos(a) * r, 0.2, Math.sin(a) * r);
            Fx.p(p, Particle.CRIT, 6, 0.2, 1.5, 0.2, 0.3);
            Fx.p(p, Particle.SOUL_FIRE_FLAME, 2, 0.1, 0.6, 0.1, 0.02);
        }
    }

    private void ambientFx() {
        if (t % 2 != 0) return;
        Location c = center.clone();
        for (int i = 0; i < 2; i++) {
            double a = rng.nextDouble() * Math.PI * 2, d = rng.nextDouble() * radius;
            Location p = c.clone().add(Math.cos(a) * d, 0.2 + rng.nextDouble() * 6, Math.sin(a) * d);
            Fx.dustForce(p, Fx.CRIMSON, 1.3f, 2, 0.3);
            Fx.p(p, Particle.ASH, 3, 0.5, 0.5, 0.5, 0.01);
        }
    }

    // ------------------------------------------------------------- slashes

    private void pulse() {
        int hit = 0;
        for (Entity e : world.getNearbyEntities(center, radius, 12, radius)) {
            if (hit >= maxTargets) break;
            if (!(e instanceof LivingEntity le) || !Dmg.eligible(plugin, owner, le)) continue;
            double dx = le.getX() - center.getX(), dz = le.getZ() - center.getZ();
            if (dx * dx + dz * dz > radius * radius) continue;
            hit++;
            Dmg.hit(plugin, owner, le, slashDamage, "domain_expansion");
            slashAt(le.getLocation().add(0, le.getHeight() * 0.5, 0));
        }
        for (int i = 0; i < 6; i++) {
            double a = rng.nextDouble() * Math.PI * 2, d = rng.nextDouble() * radius;
            slashAt(center.clone().add(Math.cos(a) * d, 0.8 + rng.nextDouble() * 3.5, Math.sin(a) * d));
        }
        Fx.sound(center, "domain_slash", 2.5f, 0.9f + rng.nextFloat() * 0.3f);
    }

    private void slashAt(Location at) {
        Vector d = new Vector(rng.nextDouble() - 0.5, rng.nextDouble() * 0.8 - 0.4, rng.nextDouble() - 0.5);
        if (d.lengthSquared() < 0.01) d = new Vector(1, 0.2, 0);
        d.normalize().multiply(2.2);
        Location a = at.clone().subtract(d), b = at.clone().add(d);
        Fx.line(a, b, Fx.CRIMSON, 1.3f, 0.3);
        Fx.line(a.clone().add(0, 0.12, 0), b.clone().add(0, 0.12, 0), Fx.WHITE, 0.8f, 0.45);
        Fx.p(at, Particle.SWEEP_ATTACK, 1, 0, 0, 0, 0);
    }

    // ------------------------------------------------- terrain transformation

    private void buildBlocks() {
        int r = (int) Math.ceil(radius);
        int cx = center.getBlockX(), cy = center.getBlockY(), cz = center.getBlockZ();
        List<int[]> pos = new ArrayList<>();
        List<BlockData> data = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (pos.size() >= MAX_BLOCKS) break;
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > radius) continue;
                int x = cx + dx, z = cz + dz;
                if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;
                int sy = Integer.MIN_VALUE;
                for (int y = cy + 3; y >= cy - 6; y--) {
                    Block b = world.getBlockAt(x, y, z);
                    Material m = b.getType();
                    if (m.isAir() || b.isPassable()) continue;
                    if (b.isLiquid()) break;
                    if (Tag.LEAVES.isTagged(m) || Tag.LOGS.isTagged(m)) continue;
                    sy = y;
                    break;
                }
                if (sy == Integer.MIN_VALUE) continue;
                int roll = (((x * 73856093) ^ (z * 19349663)) & 0x7fffffff) % 100;
                Material pick;
                if (d > radius - 1.6) pick = Material.OBSIDIAN;
                else if (roll < 2) pick = Material.GILDED_BLACKSTONE;
                else if (roll < 10) pick = Material.RED_NETHER_BRICKS;
                else if (roll < 24) pick = Material.CRACKED_POLISHED_BLACKSTONE_BRICKS;
                else if (roll < 40) pick = Material.BLACKSTONE;
                else pick = Material.POLISHED_BLACKSTONE_BRICKS;
                pos.add(new int[]{x, sy, z});
                data.add(pick.createBlockData());
            }
        }
        blockCount = pos.size();
        bx = new int[blockCount];
        by = new int[blockCount];
        bz = new int[blockCount];
        bdata = new BlockData[blockCount];
        for (int i = 0; i < blockCount; i++) {
            bx[i] = pos.get(i)[0];
            by[i] = pos.get(i)[1];
            bz[i] = pos.get(i)[2];
            bdata[i] = data.get(i);
        }
    }

    /** Sends either the fake palette or the real blocks to one player. No real block is ever modified. */
    private void sendBlocks(Player p, boolean fake) {
        if (!p.isOnline() || !p.getWorld().equals(world)) return;
        List<BlockState> states = new ArrayList<>(blockCount);
        for (int i = 0; i < blockCount; i++) {
            if (!world.isChunkLoaded(bx[i] >> 4, bz[i] >> 4)) continue;
            BlockState st = world.getBlockAt(bx[i], by[i], bz[i]).getState();
            if (fake) st.setBlockData(bdata[i]);
            states.add(st);
        }
        if (!states.isEmpty()) p.sendBlockChanges(states);
    }

    private void refreshViewers() {
        viewers.removeIf(id -> {
            Player p = Bukkit.getPlayer(id);
            return p == null || !p.isOnline() || !p.getWorld().equals(world);
        });
        for (Player p : playersNear(radius + 16)) {
            if (viewers.add(p.getUniqueId())) sendBlocks(p, true);
        }
    }

    private void updateNight() {
        for (Player p : world.getPlayers()) {
            double dx = p.getX() - center.getX(), dz = p.getZ() - center.getZ();
            boolean inside = dx * dx + dz * dz <= radius * radius;
            boolean has = nightSet.contains(p.getUniqueId());
            if (inside && !has) {
                p.setPlayerTime(18000, false);
                nightSet.add(p.getUniqueId());
            } else if (!inside && has) {
                p.resetPlayerTime();
                nightSet.remove(p.getUniqueId());
            }
        }
    }

    private void restoreAll() {
        if (restored) return;
        restored = true;
        for (UUID id : viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) sendBlocks(p, false);
        }
        viewers.clear();
        for (UUID id : nightSet) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.resetPlayerTime();
        }
        nightSet.clear();
    }

    // ------------------------------------------------------------- the shrine

    private void block(Material m, double x, double y, double z, double sx, double sy, double sz, int rise) {
        Location l = center.clone().add(x, y, z);
        l.setYaw(0);
        l.setPitch(0);
        BlockDisplay d = world.spawn(l, BlockDisplay.class, e -> {
            e.setBlock(m.createBlockData());
            e.setPersistent(false);
            e.setBrightness(new Display.Brightness(12, 12));
            e.setViewRange(3f);
            e.setTransformation(tr(sx, 0.01, sz));
        });
        plugin.effects().track(d);
        shrine.add(d);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!d.isValid()) return;
            d.setInterpolationDelay(0);
            d.setInterpolationDuration(rise);
            d.setTransformation(tr(sx, sy, sz));
        }, 2L);
    }

    private static Transformation tr(double sx, double sy, double sz) {
        return new Transformation(new Vector3f((float) (-sx / 2), 0f, (float) (-sz / 2)), new Quaternionf(),
                new Vector3f((float) sx, (float) sy, (float) sz), new Quaternionf());
    }

    private void buildShrine() {
        block(Material.POLISHED_BLACKSTONE_BRICKS, 0, 0.0, 0, 14, 0.3, 14, 30);
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                block(Material.STRIPPED_CRIMSON_STEM, sx * 6.0, 0.2, sz * 6.0, 1.3, 9, 1.3, 40);
            }
        }
        block(Material.RED_NETHER_BRICKS, 0, 9.2, 0, 17, 0.9, 17, 50);
        block(Material.BLACKSTONE, 0, 10.1, 0, 13, 0.9, 13, 55);
        block(Material.RED_NETHER_BRICKS, 0, 11.0, 0, 9, 0.9, 9, 60);
        block(Material.GILDED_BLACKSTONE, 0, 11.9, 0, 4, 1.2, 4, 65);
        block(Material.OBSIDIAN, 0, 13.1, 0, 1.2, 4, 1.2, 70);
    }

    private List<Player> playersNear(double r) {
        List<Player> out = new ArrayList<>();
        double r2 = r * r;
        for (Player p : world.getPlayers()) {
            if (p.getLocation().distanceSquared(center) <= r2) out.add(p);
        }
        return out;
    }
}
