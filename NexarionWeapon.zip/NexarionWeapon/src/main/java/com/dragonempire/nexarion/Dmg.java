package com.dragonempire.nexarion;

import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Boss;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;

/** Targeting rules and damage dealing. Damage goes through Bukkit's normal pipeline so regions/PvP plugins can veto it. */
public final class Dmg {
    /** True while we are dealing ability damage, so combat listeners do not treat it as a melee hit. */
    public static boolean internal = false;

    private Dmg() {}

    public static boolean eligible(NexarionPlugin pl, Player src, Entity e) {
        return eligible(pl, src, e, null);
    }

    public static boolean eligible(NexarionPlugin pl, Player src, Entity e, Boolean passiveOverride) {
        if (!(e instanceof LivingEntity le)) return false;
        if (e.equals(src) || e instanceof ArmorStand) return false;
        if (!le.isValid() || le.isDead() || le.isInvulnerable()) return false;
        FileConfiguration c = pl.getConfig();
        if (le instanceof Player tp) {
            if (!c.getBoolean("targeting.players", true)) return false;
            GameMode gm = tp.getGameMode();
            if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return false;
            return tp.getWorld().getPVP();
        }
        if (le instanceof Tameable t && t.isTamed()) {
            if (!c.getBoolean("targeting.tamed-pets", false)) return false;
            return t.getOwner() == null || !t.getOwner().getUniqueId().equals(src.getUniqueId());
        }
        if (le instanceof Villager || le instanceof WanderingTrader) return c.getBoolean("targeting.villagers", false);
        if (le instanceof Boss && !c.getBoolean("targeting.bosses", true)) return false;
        if (le instanceof Enemy) return c.getBoolean("targeting.hostile-mobs", true);
        return passiveOverride != null ? passiveOverride : c.getBoolean("targeting.passive-mobs", false);
    }

    /** Whether control abilities (levitate, gravity) may move this entity. Bosses are never moved unless allowed. */
    public static boolean controllable(NexarionPlugin pl, Player src, Entity e, Boolean passiveOverride) {
        if (e instanceof Boss) return false;
        return eligible(pl, src, e, passiveOverride);
    }

    /** An entity that is hostile toward the owner (used by defensive abilities). */
    public static boolean isThreat(Player owner, Entity e) {
        if (e == null || e.equals(owner)) return false;
        if (e instanceof Projectile) return true;
        if (e instanceof Player p) {
            return p.getWorld().getPVP() && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR;
        }
        if (e instanceof Enemy) return true;
        return e instanceof Mob m && owner.equals(m.getTarget());
    }

    public static boolean hit(NexarionPlugin pl, Player src, LivingEntity t, double dmg, String essenceKey) {
        if (!eligible(pl, src, t)) return false;
        return hitRaw(pl, src, t, dmg, essenceKey);
    }

    public static boolean hitRaw(NexarionPlugin pl, Player src, LivingEntity t, double dmg, String essenceKey) {
        double before = t.getHealth();
        boolean prev = internal;
        internal = true;
        try {
            t.damage(dmg, src);
        } finally {
            internal = prev;
        }
        double after = t.isDead() ? 0 : t.getHealth();
        if (before - after < 0.01 && !t.isDead()) return false; // vetoed (region/PvP) or fully absorbed
        if (essenceKey != null) pl.essence().award(src, essenceKey, t);
        return true;
    }
}
