package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.logging.Level;

/** A timed, owner-bound effect with guaranteed cleanup. */
public abstract class Effect {
    protected final NexarionPlugin plugin;
    protected final Player owner;
    protected int t;
    private BukkitTask task;
    private boolean ended;

    protected Effect(NexarionPlugin plugin, Player owner) {
        this.plugin = plugin;
        this.owner = owner;
    }

    public Player owner() {
        return owner;
    }

    public boolean isEnded() {
        return ended;
    }

    public Ability ability() {
        return null;
    }

    /** Whether a world change by the owner ends this effect. */
    public boolean endsOnWorldChange() {
        return true;
    }

    public final void start(long period) {
        plugin.effects().add(this);
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (ended) return;
            if (!owner.isOnline() || owner.isDead()) {
                end();
                return;
            }
            try {
                tick();
                t++;
            } catch (Throwable ex) {
                plugin.getLogger().log(Level.WARNING, "Effect " + getClass().getSimpleName() + " failed and was stopped", ex);
                end();
            }
        }, 0L, period);
    }

    protected abstract void tick();

    protected abstract void cleanup();

    public final void end() {
        if (ended) return;
        ended = true;
        if (task != null) task.cancel();
        try {
            cleanup();
        } catch (Throwable ex) {
            plugin.getLogger().log(Level.WARNING, "Cleanup of " + getClass().getSimpleName() + " failed", ex);
        } finally {
            plugin.effects().remove(this);
        }
    }
}
