package com.dragonempire.nexarion;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Magic Essence: earned by dealing ability damage, spent on casting. Persisted to essence.yml. */
public final class EssenceManager {
    private final NexarionPlugin pl;
    private final File file;
    private final Map<UUID, Integer> map = new HashMap<>();
    private boolean dirty;

    // anti-abuse windows: key -> {windowStart, amountInWindow, lastAward}
    private final Map<String, long[]> perTarget = new HashMap<>();
    private final Map<UUID, long[]> perMinute = new HashMap<>();
    private final Map<UUID, long[]> perHour = new HashMap<>();

    public EssenceManager(NexarionPlugin pl) {
        this.pl = pl;
        this.file = new File(pl.getDataFolder(), "essence.yml");
    }

    public int max() {
        return Math.max(1, pl.getConfig().getInt("essence.max", 1000));
    }

    public int get(UUID id) {
        return Math.min(map.getOrDefault(id, 0), max());
    }

    public void set(UUID id, int v) {
        map.put(id, Math.max(0, Math.min(v, max())));
        dirty = true;
    }

    public void add(UUID id, int v) {
        set(id, get(id) + v);
    }

    public void reset(UUID id) {
        map.remove(id);
        dirty = true;
    }

    public int cost(String key) {
        return Math.max(0, pl.getConfig().getInt("essence.costs." + key, 0));
    }

    /**
     * Awards essence for a damage event that really landed. Returns the amount actually granted.
     */
    public int award(Player p, String key, LivingEntity target) {
        FileConfiguration c = pl.getConfig();
        int amt = c.getInt("essence.awards." + key, 0);
        if (amt <= 0 || target == null || target.getUniqueId().equals(p.getUniqueId())) return 0;
        long now = System.currentTimeMillis();

        String tk = p.getUniqueId() + ":" + target.getUniqueId();
        long[] tw = perTarget.computeIfAbsent(tk, k -> new long[]{now, 0, 0});
        if (now - tw[0] > 60_000) { tw[0] = now; tw[1] = 0; }
        if (now - tw[2] < c.getInt("essence.award-cooldown-ticks", 10) * 50L) return 0;
        amt = (int) Math.min(amt, c.getInt("essence.per-target-per-minute-cap", 40) - tw[1]);

        long[] mw = perMinute.computeIfAbsent(p.getUniqueId(), k -> new long[]{now, 0});
        if (now - mw[0] > 60_000) { mw[0] = now; mw[1] = 0; }
        amt = (int) Math.min(amt, c.getInt("essence.per-player-per-minute-cap", 220) - mw[1]);

        long[] hw = perHour.computeIfAbsent(p.getUniqueId(), k -> new long[]{now, 0});
        if (now - hw[0] > 3_600_000L) { hw[0] = now; hw[1] = 0; }
        amt = (int) Math.min(amt, c.getInt("essence.per-player-per-hour-cap", 4000) - hw[1]);

        int cur = get(p.getUniqueId());
        amt = Math.min(amt, max() - cur);
        if (amt <= 0) return 0;

        tw[1] += amt; tw[2] = now; mw[1] += amt; hw[1] += amt;
        map.put(p.getUniqueId(), cur + amt);
        dirty = true;

        // feedback: stream of motes from the target to the wielder
        Location from = target.getLocation().add(0, target.getHeight() * 0.6, 0);
        Location to = p.getLocation().add(0, 1.2, 0);
        Fx.line(from, to, Color.fromRGB(0xFFD24D), 0.9f, 1.4);
        Fx.sound(p.getLocation(), "essence_gain", 0.5f, 1.0f + (float) cur / max() * 0.5f);
        pl.hud().flash(p, "<gold>+" + amt + " ✦ <gray>Essence");
        return amt;
    }

    public boolean consume(Player p, int amount) {
        if (amount <= 0) return true;
        int cur = get(p.getUniqueId());
        if (cur < amount) return false;
        map.put(p.getUniqueId(), cur - amount);
        dirty = true;
        pl.hud().flash(p, "<red>-" + amount + " ✦ <gray>Essence");
        return true;
    }

    public void cleanup(UUID id) {
        perMinute.remove(id);
        perHour.remove(id);
        perTarget.keySet().removeIf(k -> k.startsWith(id.toString()));
    }

    public void sweep() {
        long now = System.currentTimeMillis();
        perTarget.values().removeIf(w -> now - w[0] > 120_000);
        perMinute.values().removeIf(w -> now - w[0] > 120_000);
    }

    public void load() {
        map.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("players");
        if (s == null) return;
        for (String k : s.getKeys(false)) {
            try {
                map.put(UUID.fromString(k), Math.max(0, s.getInt(k)));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        if (!dirty && file.exists()) return;
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Integer> e : map.entrySet()) y.set("players." + e.getKey(), e.getValue());
        try {
            pl.getDataFolder().mkdirs();
            File tmp = new File(pl.getDataFolder(), "essence.yml.tmp");
            y.save(tmp);
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            dirty = false;
        } catch (IOException ex) {
            pl.getLogger().severe("Could not save essence.yml: " + ex.getMessage());
        }
    }
}
