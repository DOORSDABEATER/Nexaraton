package com.dragonempire.nexarion;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;

/** Particles, sounds and display-entity helpers. */
public final class Fx {
    public static final Color VIOLET = Color.fromRGB(0x7B2CFF);
    public static final Color LILAC = Color.fromRGB(0xC9A6FF);
    public static final Color GOLD = Color.fromRGB(0xFFD24D);
    public static final Color CRIMSON = Color.fromRGB(0xD81B3C);
    public static final Color WHITE = Color.fromRGB(0xFFFFFF);
    public static final Color CYAN = Color.fromRGB(0x4DE1FF);
    public static final Color ORANGE = Color.fromRGB(0xFF7A1A);

    private static NexarionPlugin pl;
    private static final Map<String, Object[]> VANILLA = new HashMap<>();

    static {
        v("staff_activate", Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1.4f);
        v("sword_swing", Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.7f);
        v("sword_hit", Sound.ENTITY_PLAYER_ATTACK_STRONG, 0.8f);
        v("dagger_throw", Sound.ITEM_TRIDENT_THROW, 1.8f);
        v("dagger_hit", Sound.ITEM_TRIDENT_HIT, 1.6f);
        v("air_slash", Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.5f);
        v("air_slash_hit", Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.8f);
        v("fireball_cast", Sound.ENTITY_BLAZE_SHOOT, 0.7f);
        v("fireball_explode", Sound.ENTITY_GENERIC_EXPLODE, 1.2f);
        v("levitate", Sound.ENTITY_EVOKER_CAST_SPELL, 1.3f);
        v("simple_domain", Sound.BLOCK_BEACON_ACTIVATE, 1.8f);
        v("simple_domain_counter", Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.6f);
        v("infinity_on", Sound.BLOCK_BEACON_ACTIVATE, 0.6f);
        v("infinity_off", Sound.BLOCK_BEACON_DEACTIVATE, 0.6f);
        v("domain_expansion", Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f);
        v("domain_slash", Sound.ENTITY_PLAYER_ATTACK_SWEEP, 0.6f);
        v("domain_end", Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f);
        v("gravity_bending", Sound.ENTITY_WITHER_SPAWN, 0.5f);
        v("gravity_pulse", Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.5f);
        v("essence_gain", Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.2f);
        v("transform", Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f);
        v("equip", Sound.ITEM_ARMOR_EQUIP_NETHERITE, 1.2f);
        v("deny", Sound.ENTITY_VILLAGER_NO, 1.0f);
        v("select", Sound.UI_BUTTON_CLICK, 1.6f);
    }

    private Fx() {}

    public static void init(NexarionPlugin plugin) {
        pl = plugin;
    }

    private static void v(String key, Sound s, float pitch) {
        VANILLA.put(key, new Object[]{s, pitch});
    }

    // ------------------------------------------------------------------ sound

    public static void sound(Location l, String key, float vol, float pitch) {
        if (l == null || l.getWorld() == null) return;
        boolean custom = pl == null || !"vanilla".equalsIgnoreCase(pl.getConfig().getString("sounds.mode", "custom"));
        if (custom) {
            l.getWorld().playSound(l, "nexarion:" + key, SoundCategory.PLAYERS, vol, pitch);
        } else {
            Object[] o = VANILLA.get(key);
            if (o != null) l.getWorld().playSound(l, (Sound) o[0], SoundCategory.PLAYERS, vol, pitch * (Float) o[1]);
        }
    }

    // --------------------------------------------------------------- particles

    public static void dust(Location l, Color c, float size, int count, double spread) {
        l.getWorld().spawnParticle(Particle.DUST, l, count, spread, spread, spread, 0, new Particle.DustOptions(c, size));
    }

    public static void dustForce(Location l, Color c, float size, int count, double spread) {
        l.getWorld().spawnParticle(Particle.DUST, l, count, spread, spread, spread, 0, new Particle.DustOptions(c, size), true);
    }

    public static void p(Location l, Particle particle, int count, double dx, double dy, double dz, double speed) {
        l.getWorld().spawnParticle(particle, l, count, dx, dy, dz, speed);
    }

    public static void ring(Location c, double r, int pts, double rot, Color col, float size) {
        World w = c.getWorld();
        Particle.DustOptions o = new Particle.DustOptions(col, size);
        for (int i = 0; i < pts; i++) {
            double a = rot + Math.PI * 2 * i / pts;
            w.spawnParticle(Particle.DUST, c.getX() + Math.cos(a) * r, c.getY(), c.getZ() + Math.sin(a) * r, 1, 0, 0, 0, 0, o, true);
        }
    }

    public static void sphere(Location c, double r, int pts, double rot, Color col, float size) {
        World w = c.getWorld();
        Particle.DustOptions o = new Particle.DustOptions(col, size);
        double golden = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < pts; i++) {
            double y = 1 - 2.0 * (i + 0.5) / pts;
            double rad = Math.sqrt(Math.max(0, 1 - y * y));
            double th = golden * i + rot;
            w.spawnParticle(Particle.DUST, c.getX() + Math.cos(th) * rad * r, c.getY() + y * r, c.getZ() + Math.sin(th) * rad * r,
                    1, 0, 0, 0, 0, o);
        }
    }

    public static void line(Location a, Location b, Color col, float size, double step) {
        if (a.getWorld() == null || !a.getWorld().equals(b.getWorld())) return;
        Vector d = b.toVector().subtract(a.toVector());
        double len = d.length();
        if (len < 0.01) return;
        d.normalize();
        Particle.DustOptions o = new Particle.DustOptions(col, size);
        for (double t = 0; t <= len; t += step) {
            a.getWorld().spawnParticle(Particle.DUST, a.getX() + d.getX() * t, a.getY() + d.getY() * t, a.getZ() + d.getZ() * t,
                    1, 0, 0, 0, 0, o);
        }
    }

    // --------------------------------------------------------------- displays

    /** Spawns a non-persistent item display that uses a nexarion:<model> item model. */
    public static ItemDisplay itemDisplay(Location loc, Material base, String model, float scale, boolean billboard) {
        ItemStack is = new ItemStack(base);
        ItemMeta m = is.getItemMeta();
        m.setItemModel(NamespacedKey.fromString("nexarion:" + model));
        is.setItemMeta(m);
        ItemDisplay d = loc.getWorld().spawn(loc, ItemDisplay.class, e -> {
            e.setItemStack(is);
            e.setPersistent(false);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            e.setBillboard(billboard ? Display.Billboard.CENTER : Display.Billboard.FIXED);
            e.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(scale, scale, scale), new Quaternionf()));
            e.setTeleportDuration(1);
            e.setInterpolationDuration(1);
        });
        if (pl != null) pl.effects().track(d);
        return d;
    }

    public static void removeDisplay(org.bukkit.entity.Entity e) {
        if (e == null) return;
        if (pl != null) pl.effects().untrack(e);
        if (e.isValid()) e.remove();
    }

    /** A short-lived animated crescent slash sprite in front of a point. */
    public static void slashDisplay(Location at, Vector dir, float rollRad, float size, int life) {
        Location l = at.clone();
        l.setDirection(dir);
        ItemDisplay d = itemDisplay(l, Material.PAPER, "slash", 0.2f, false);
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(Math.max(2, life - 1));
        org.bukkit.Bukkit.getScheduler().runTaskLater(pl, () -> {
            if (!d.isValid()) return;
            d.setInterpolationDelay(0);
            d.setInterpolationDuration(Math.max(2, life - 1));
            d.setTransformation(new Transformation(new Vector3f(), new Quaternionf().rotateZ(rollRad), new Vector3f(size, size, size), new Quaternionf()));
        }, 1L);
        org.bukkit.Bukkit.getScheduler().runTaskLater(pl, () -> removeDisplay(d), life + 1L);
    }
}
