package com.dragonempire.nexarion.effects;

import com.dragonempire.nexarion.Ability;
import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Spatial barrier: hostile attacks never arrive, approaching things slow toward the boundary. Hard-capped duration. */
public final class InfinityEffect extends Effect {
    private static final int HARD_CAP_SECONDS = 30;
    private final double radius;
    private final int durationRuns; // period 2 ticks
    private final Set<EntityDamageEvent.DamageCause> causes = new HashSet<>();

    public InfinityEffect(NexarionPlugin pl, Player owner) {
        super(pl, owner);
        var c = pl.getConfig();
        this.radius = Math.max(1.5, c.getDouble("abilities.infinity.radius", 3.5));
        double secs = Math.min(HARD_CAP_SECONDS, Math.max(1.0, c.getDouble("abilities.infinity.duration", 8.0)));
        this.durationRuns = (int) (secs * 10);
        List<String> names = c.getStringList("abilities.infinity.blocked-causes");
        for (String n : names) {
            try {
                causes.add(EntityDamageEvent.DamageCause.valueOf(n.toUpperCase()));
            } catch (IllegalArgumentException ex) {
                pl.getLogger().warning("Unknown damage cause in infinity.blocked-causes: " + n);
            }
        }
    }

    @Override
    public Ability ability() {
        return Ability.INFINITY;
    }

    public int secondsLeft() {
        return Math.max(0, (durationRuns - t) / 10);
    }

    /** True if this damage event is stopped by the barrier. */
    public boolean blocks(EntityDamageEvent e, Entity source, LivingEntity attacker) {
        if (isEnded() || !causes.contains(e.getCause())) return false;
        if (attacker != null) return Dmg.isThreat(owner, attacker);
        return true; // TNT, block explosions, magic with no living source
    }

    public void onBlocked(Entity source) {
        Location at = owner.getLocation().add(0, 1, 0);
        if (source != null) {
            Vector away = source.getLocation().toVector().subtract(owner.getLocation().toVector()).setY(0);
            if (away.lengthSquared() > 0.01 && source instanceof LivingEntity le) {
                le.setVelocity(le.getVelocity().add(away.normalize().multiply(0.6).setY(0.15)));
            }
            Location edge = at.clone().add(source.getLocation().toVector().subtract(at.toVector()).normalize().multiply(radius));
            Fx.p(edge, Particle.REVERSE_PORTAL, 20, 0.2, 0.2, 0.2, 0.15);
            Fx.p(edge, Particle.END_ROD, 6, 0.1, 0.1, 0.1, 0.05);
        }
        Fx.sound(at, "infinity_on", 0.4f, 1.8f);
    }

    @Override
    protected void tick() {
        if (t == 0) {
            Fx.sound(owner.getLocation(), "infinity_on", 1f, 1f);
            plugin.hud().flash(owner, "<aqua>∞ Infinity <gray>- nothing reaches you");
        }
        if (t >= durationRuns) {
            end();
            return;
        }
        Location c = owner.getLocation().add(0, 1.0, 0);
        double grow = Math.min(1.0, t / 5.0);
        Fx.sphere(c, radius * grow, 46, t * 0.12, Fx.CYAN, 0.8f);
        if (t % 2 == 0) {
            Fx.sphere(c, radius * grow * 0.96, 14, -t * 0.2, Fx.WHITE, 0.6f);
            Fx.p(c.clone().add(radius * 0.7 * Math.cos(t), Math.sin(t * 0.5), radius * 0.7 * Math.sin(t)), Particle.REVERSE_PORTAL, 4, 0.1, 0.1, 0.1, 0.2);
        }
        double outer = radius + 1.4;
        for (Entity en : owner.getNearbyEntities(outer, outer, outer)) {
            double d = en.getLocation().add(0, en.getHeight() * 0.5, 0).distance(c);
            if (en instanceof Projectile pr) {
                if (owner.equals(pr.getShooter())) continue;
                Vector v = pr.getVelocity();
                double factor = Math.max(0.0, (d - radius) / 1.4); // slows toward the boundary, never crosses
                pr.setVelocity(v.multiply(factor * 0.6));
                if (d <= radius + 0.25) {
                    Fx.p(pr.getLocation(), Particle.REVERSE_PORTAL, 10, 0.1, 0.1, 0.1, 0.2);
                    pr.remove();
                }
            } else if (en instanceof LivingEntity le && d < radius && Dmg.isThreat(owner, le)) {
                Vector away = le.getLocation().toVector().subtract(owner.getLocation().toVector()).setY(0);
                if (away.lengthSquared() < 0.01) away = new Vector(1, 0, 0);
                le.setVelocity(away.normalize().multiply(0.45).setY(0.1));
            }
        }
    }

    @Override
    protected void cleanup() {
        Fx.sound(owner.getLocation(), "infinity_off", 1f, 1f);
        Fx.p(owner.getLocation().add(0, 1, 0), Particle.END_ROD, 25, radius * 0.5, 0.8, radius * 0.5, 0.05);
    }
}
