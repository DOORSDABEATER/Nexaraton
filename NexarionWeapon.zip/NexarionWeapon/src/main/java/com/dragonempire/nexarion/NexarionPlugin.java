package com.dragonempire.nexarion;

import com.dragonempire.nexarion.effects.EffectManager;
import com.dragonempire.nexarion.listeners.CombatListener;
import com.dragonempire.nexarion.listeners.SafetyListener;
import com.dragonempire.nexarion.listeners.WeaponListener;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class NexarionPlugin extends JavaPlugin {
    private ItemFactory items;
    private EssenceManager essence;
    private Cooldowns cooldowns;
    private EffectManager effects;
    private AbilityManager abilities;
    private Controls controls;
    private Hud hud;
    private GravityGuard gravity;
    private InspectGui gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Fx.init(this);
        items = new ItemFactory(this);
        essence = new EssenceManager(this);
        essence.load();
        cooldowns = new Cooldowns();
        effects = new EffectManager();
        gravity = new GravityGuard(this);
        controls = new Controls(this);
        abilities = new AbilityManager(this);
        hud = new Hud(this);
        gui = new InspectGui(this);

        WeaponListener weapon = new WeaponListener(this);
        CombatListener combat = new CombatListener(this, weapon);
        Bukkit.getPluginManager().registerEvents(weapon, this);
        Bukkit.getPluginManager().registerEvents(combat, this);
        Bukkit.getPluginManager().registerEvents(new SafetyListener(this, weapon, combat), this);
        Bukkit.getPluginManager().registerEvents(gui, this);

        PluginCommand cmd = getCommand("nexarion");
        if (cmd != null) {
            NexCommand nc = new NexCommand(this);
            cmd.setExecutor(nc);
            cmd.setTabCompleter(nc);
        }
        hud.start();
        Bukkit.getScheduler().runTaskTimer(this, () -> essence.save(), 6000L, 6000L);
        if (Bukkit.getPluginManager().isPluginEnabled("DeSWeaponExpansion")) {
            getLogger().info("DeSWeaponExpansion detected - running side by side (no shared state).");
        }
        getLogger().info("NEXARION - The Boundless Sovereign is awake.");
    }

    @Override
    public void onDisable() {
        if (hud != null) hud.stop();
        if (effects != null) effects.endAll();          // restores terrain, time, movement
        if (gravity != null) gravity.releaseAll();
        if (effects != null) effects.removeAllTracked(); // removes every temporary display entity
        if (essence != null) essence.save();
    }

    public void reloadAll() {
        reloadConfig();
        controls.reload();
    }

    public boolean isDisabledWorld(World w) {
        return getConfig().getStringList("disabled-worlds").contains(w.getName());
    }

    public ItemFactory items() { return items; }
    public EssenceManager essence() { return essence; }
    public Cooldowns cooldowns() { return cooldowns; }
    public EffectManager effects() { return effects; }
    public AbilityManager abilities() { return abilities; }
    public Controls controls() { return controls; }
    public Hud hud() { return hud; }
    public GravityGuard gravity() { return gravity; }
    public InspectGui gui() { return gui; }
}
