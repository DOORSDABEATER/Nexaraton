package com.dragonempire.nexarion.listeners;

import com.dragonempire.nexarion.Controls;
import com.dragonempire.nexarion.Dmg;
import com.dragonempire.nexarion.Form;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import com.dragonempire.nexarion.effects.InfinityEffect;
import com.dragonempire.nexarion.effects.SimpleDomainEffect;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CombatListener implements Listener {
    private final NexarionPlugin pl;
    private final WeaponListener input;
    private final Map<UUID, int[]> combo = new HashMap<>(); // {count, lastTick}

    public CombatListener(NexarionPlugin pl, WeaponListener input) {
        this.pl = pl;
        this.input = input;
    }

    public void forget(UUID id) {
        combo.remove(id);
    }

    /** Infinity and Simple Domain intercept incoming damage to the wielder. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDefend(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        InfinityEffect inf = pl.effects().find(victim.getUniqueId(), InfinityEffect.class);
        SimpleDomainEffect sd = pl.effects().find(victim.getUniqueId(), SimpleDomainEffect.class);
        if (inf == null && sd == null) return;

        Entity source = null;
        LivingEntity attacker = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            source = be.getDamager();
            if (source instanceof Projectile pr && pr.getShooter() instanceof LivingEntity s) attacker = s;
            else if (source instanceof LivingEntity l) attacker = l;
        }
        if (inf != null && inf.blocks(e, source, attacker)) {
            e.setCancelled(true);
            inf.onBlocked(source);
            return;
        }
        if (sd != null && source != null && sd.absorb(source, attacker)) e.setCancelled(true);
    }

    /** Melee: Shift+Left Click on a nearby mob must still cycle/throw; sword & dagger get their combo bonuses. */
    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onMelee(EntityDamageByEntityEvent e) {
        if (Dmg.internal || e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!(e.getDamager() instanceof Player p)) return;
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!pl.items().isNexarion(it) || pl.isDisabledWorld(p.getWorld())) return;
        Form f = pl.items().form(it);

        if (p.isSneaking()) {
            Controls.Action act = pl.controls().resolve(Controls.Input.SHIFT_LEFT_CLICK, f);
            if (act != null) {
                e.setCancelled(true);
                if (input.debounce(p, Controls.Input.SHIFT_LEFT_CLICK)) input.perform(p, it, act);
                return;
            }
        }
        if (f == Form.STAFF || !(e.getEntity() instanceof LivingEntity)) return;

        int now = Bukkit.getCurrentTick();
        int[] c = combo.computeIfAbsent(p.getUniqueId(), k -> new int[]{0, now});
        if (now - c[1] > 60) c[0] = 0;
        c[0]++;
        c[1] = now;
        double bonus = 0;
        Location at = e.getEntity().getLocation().add(0, 1.0, 0);
        if (f == Form.SWORD) {
            if (c[0] % Math.max(1, pl.getConfig().getInt("forms.sword.finisher-every", 4)) == 0) {
                bonus = pl.getConfig().getDouble("forms.sword.finisher-bonus", 3.0);
                Fx.p(at, Particle.SWEEP_ATTACK, 3, 0.6, 0.3, 0.6, 0.0);
                Fx.p(at, Particle.ENCHANTED_HIT, 25, 0.4, 0.5, 0.4, 0.4);
                Fx.dust(at, Fx.GOLD, 1.6f, 15, 0.5);
                Fx.sound(at, "sword_hit", 1.2f, 0.7f);
            } else {
                Fx.p(at, Particle.CRIT, 6, 0.3, 0.3, 0.3, 0.2);
                Fx.sound(at, "sword_hit", 0.8f, 1f);
            }
        } else {
            if (c[0] % Math.max(1, pl.getConfig().getInt("forms.dagger.flurry-every", 3)) == 0) {
                bonus = pl.getConfig().getDouble("forms.dagger.flurry-bonus", 2.0);
                Fx.dust(at, Fx.CRIMSON, 1.4f, 14, 0.4);
                Fx.p(at, Particle.CRIT, 14, 0.3, 0.4, 0.3, 0.35);
            } else {
                Fx.p(at, Particle.CRIT, 3, 0.2, 0.2, 0.2, 0.1);
            }
            Fx.sound(at, "dagger_hit", 0.7f, 1.3f);
        }
        if (bonus > 0) e.setDamage(e.getDamage() + bonus);
    }

    /** Essence for melee hits that really landed (after other plugins had their say). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMeleeLanded(EntityDamageByEntityEvent e) {
        if (Dmg.internal || e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        if (!(e.getDamager() instanceof Player p) || !(e.getEntity() instanceof LivingEntity t)) return;
        if (e.getFinalDamage() <= 0) return;
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!pl.items().isNexarion(it)) return;
        String key = switch (pl.items().form(it)) {
            case SWORD -> "sword_melee";
            case DAGGER -> "dagger_melee";
            case STAFF -> null;
        };
        if (key != null && Dmg.eligible(pl, p, t)) pl.essence().award(p, key, t);
    }
}
