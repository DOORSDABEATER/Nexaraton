package com.dragonempire.nexarion.listeners;

import com.dragonempire.nexarion.Controls;
import com.dragonempire.nexarion.Form;
import com.dragonempire.nexarion.Fx;
import com.dragonempire.nexarion.NexarionPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Input handling: translates clicks / swaps into configured actions, with debounce and vanilla-safety. */
public final class WeaponListener implements Listener {
    private final NexarionPlugin pl;
    private final Map<UUID, EnumMap<Controls.Input, Integer>> last = new HashMap<>();
    private final Map<UUID, Integer> lastSwing = new HashMap<>();

    public WeaponListener(NexarionPlugin pl) {
        this.pl = pl;
    }

    public void forget(UUID id) {
        last.remove(id);
        lastSwing.remove(id);
    }

    /** Prevents one physical input from firing twice (several events per click). */
    public boolean debounce(Player p, Controls.Input in) {
        int now = Bukkit.getCurrentTick();
        int gap = pl.getConfig().getInt("controls.debounce-ticks", 4);
        EnumMap<Controls.Input, Integer> m = last.computeIfAbsent(p.getUniqueId(), k -> new EnumMap<>(Controls.Input.class));
        Integer l = m.get(in);
        if (l != null && now - l < gap) return false;
        m.put(in, now);
        return true;
    }

    public void perform(Player p, ItemStack it, Controls.Action a) {
        switch (a) {
            case CYCLE_ABILITY -> pl.abilities().cycle(p, it);
            case SWITCH_FORM -> pl.abilities().switchForm(p, it);
            case TOGGLE_DAGGER -> pl.abilities().toggleDagger(p, it);
            case ACTIVATE -> pl.abilities().activateSelected(p, it);
            case THROW_DAGGER -> pl.abilities().throwDagger(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a == Action.PHYSICAL) return;
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!pl.items().isNexarion(it) || pl.isDisabledWorld(p.getWorld())) return;

        boolean right = a.isRightClick();
        boolean sneak = p.isSneaking();
        // Never steal vanilla interactions (chests, doors, buttons...) from a plain right click.
        if (right && !sneak && a == Action.RIGHT_CLICK_BLOCK && e.getClickedBlock() != null
                && e.getClickedBlock().getType().isInteractable()) return;

        Controls.Input in;
        if (right) in = sneak ? Controls.Input.SHIFT_RIGHT_CLICK : Controls.Input.RIGHT_CLICK;
        else if (sneak) in = Controls.Input.SHIFT_LEFT_CLICK;
        else return; // plain left click = vanilla melee

        Controls.Action act = pl.controls().resolve(in, pl.items().form(it));
        if (act == null) return;
        e.setCancelled(true);
        if (!debounce(p, in)) return;
        perform(p, it, act);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!pl.items().isNexarion(it) || pl.isDisabledWorld(p.getWorld())) return;
        e.setCancelled(true); // the weapon never moves to the off-hand by accident
        Controls.Input in = p.isSneaking() ? Controls.Input.SHIFT_F : Controls.Input.F;
        Controls.Action act = pl.controls().resolve(in, pl.items().form(it));
        if (act == null || !debounce(p, in)) return;
        perform(p, it, act);
    }

    @EventHandler
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItem(e.getNewSlot());
        if (!pl.items().isNexarion(it)) return;
        Location l = p.getLocation().add(0, 1, 0);
        Fx.sound(l, "equip", 0.8f, 1f);
        Fx.p(l, org.bukkit.Particle.ENCHANT, 25, 0.5, 0.8, 0.5, 0.6);
    }

    /** Swing feedback: sword/dagger slash sprite and sound on every arm swing. */
    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (!pl.items().isNexarion(it)) return;
        Form f = pl.items().form(it);
        if (f == Form.STAFF) return;
        int now = Bukkit.getCurrentTick();
        Integer l = lastSwing.get(p.getUniqueId());
        if (l != null && now - l < 3) return;
        lastSwing.put(p.getUniqueId(), now);
        if (p.isSneaking() && f == Form.DAGGER) return; // that swing is a throw
        Vector dir = p.getEyeLocation().getDirection();
        float roll = (now % 2 == 0) ? 0.5f : -0.5f;
        Location at = p.getEyeLocation().add(dir.clone().multiply(1.5));
        Fx.slashDisplay(at, dir, roll, f == Form.SWORD ? 2.2f : 1.3f, 4);
        Fx.sound(p.getLocation(), "sword_swing", 0.6f, f == Form.DAGGER ? 1.5f : 1.0f);
    }
}
