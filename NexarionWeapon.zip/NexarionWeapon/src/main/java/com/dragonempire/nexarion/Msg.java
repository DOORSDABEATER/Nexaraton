package com.dragonempire.nexarion;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;

public final class Msg {
    public static final MiniMessage MM = MiniMessage.miniMessage();
    public static final String PREFIX = "<gradient:#8a5cff:#ffd24d><b>NEXARION</b></gradient> <dark_gray>»</dark_gray> <gray>";

    private Msg() {}

    public static Component c(String s) {
        return MM.deserialize(s);
    }

    public static void send(CommandSender to, String s) {
        to.sendMessage(c(PREFIX + s));
    }
}
