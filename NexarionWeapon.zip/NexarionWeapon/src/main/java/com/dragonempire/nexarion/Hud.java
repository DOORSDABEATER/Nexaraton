package com.dragonempire.nexarion;

import com.dragonempire.nexarion.effects.DomainExpansionEffect;
import com.dragonempire.nexarion.effects.GravityBendingEffect;
import com.dragonempire.nexarion.effects.InfinityEffect;
import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Action bar + boss bar: essence, selected ability, ultimate availability. One repeating task for everything. */
public final class Hud {
    private final NexarionPlugin pl;
    private BukkitTask task;
    private int counter;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Integer> flashUntil = new HashMap<>();

    public Hud(NexarionPlugin pl) {
        this.pl = pl;
    }

    public void start() {
        task = Bukkit.getScheduler().runTaskTimer(pl, this::tick, 20L, 10L);
    }

    public void stop() {
        if (task != null) task.cancel();
        for (Map.Entry<UUID, BossBar> e : bars.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) p.hideBossBar(e.getValue());
        }
        bars.clear();
        flashUntil.clear();
    }

    public void remove(UUID id) {
        bars.remove(id);
        flashUntil.remove(id);
    }

    /** Transient action-bar message (essence gain/spend, selection, cooldown feedback). */
    public void flash(Player p, String mm) {
        flashUntil.put(p.getUniqueId(), Bukkit.getCurrentTick() + 30);
        p.sendActionBar(Msg.c(mm));
    }

    private void tick() {
        counter++;
        int now = Bukkit.getCurrentTick();
        boolean actionbar = pl.getConfig().getBoolean("hud.actionbar", true);
        boolean bossbar = pl.getConfig().getBoolean("hud.bossbar", true);
        boolean particles = pl.getConfig().getBoolean("hud.passive-particles", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            ItemStack it = p.getInventory().getItemInMainHand();
            if (!pl.items().isNexarion(it)) {
                hideBar(p);
                continue;
            }
            UUID id = p.getUniqueId();
            int ess = pl.essence().get(id);
            int max = pl.essence().max();
            Form f = pl.items().form(it);
            if (bossbar) showBar(p, ess, max);
            if (actionbar && flashUntil.getOrDefault(id, 0) <= now) p.sendActionBar(Msg.c(line(p, it, f, ess, max)));
            if (particles && counter % 2 == 0) {
                var col = f == Form.STAFF ? Fx.VIOLET : f == Form.SWORD ? Fx.GOLD : Fx.CRIMSON;
                Fx.dust(p.getLocation().add(0, 1.0, 0), col, 0.8f, 2, 0.45);
                if (ess >= max) Fx.p(p.getLocation().add(0, 2.1, 0), Particle.END_ROD, 1, 0.2, 0.05, 0.2, 0.0);
            }
        }
        if (counter % 20 == 0) {
            pl.effects().sweepTracked();
            pl.essence().sweep();
        }
        bars.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    private String line(Player p, ItemStack it, Form f, int ess, int max) {
        UUID id = p.getUniqueId();
        List<Ability> list = f.abilities();
        Ability a = list.get(Math.min(pl.items().selected(it), list.size() - 1));
        StringBuilder sb = new StringBuilder();
        int filled = Math.round(10f * ess / max);
        sb.append("<light_purple>✦ <gold>").append(ess).append("<dark_gray>/").append(max).append(" ");
        sb.append("<light_purple>").append("▮".repeat(filled)).append("<dark_gray>").append("▯".repeat(10 - filled));
        sb.append(" <dark_gray>│ <white>").append(f.display);
        sb.append(" <dark_gray>│ ").append(a.ultimate ? "<gold>★ " : "<light_purple>▶ ").append("<white>").append(a.display);
        long rem = pl.cooldowns().remainingMs(id, a);
        if (rem > 0) sb.append(" <red>").append(String.format("%.1fs", rem / 1000.0));
        else if (ess < pl.abilities().cost(a)) sb.append(" <red>(").append(pl.abilities().cost(a)).append(" ✦)");
        else sb.append(" <green>ready");
        if (f == Form.STAFF) {
            sb.append(" <dark_gray>│ ").append(ult(id, ess, Ability.DOMAIN_EXPANSION, "DOM"));
            sb.append(" ").append(ult(id, ess, Ability.GRAVITY_BENDING, "GRV"));
        }
        GravityBendingEffect g = pl.effects().find(id, GravityBendingEffect.class);
        if (g != null) sb.append(" <dark_gray>│ <aqua>GRV ").append(g.secondsLeft()).append("s ").append(g.mode().label);
        DomainExpansionEffect d = pl.effects().find(id, DomainExpansionEffect.class);
        if (d != null) sb.append(" <dark_gray>│ <red>DOM ").append(d.secondsLeft()).append("s");
        InfinityEffect inf = pl.effects().find(id, InfinityEffect.class);
        if (inf != null) sb.append(" <dark_gray>│ <aqua>∞ ").append(inf.secondsLeft()).append("s");
        return sb.toString();
    }

    private String ult(UUID id, int ess, Ability a, String tag) {
        boolean ok = pl.cooldowns().ready(id, a) && ess >= pl.abilities().cost(a);
        return (ok ? "<green>" + tag + " ◆" : "<red>" + tag + " ◇");
    }

    private void showBar(Player p, int ess, int max) {
        BossBar bar = bars.get(p.getUniqueId());
        if (bar == null) {
            bar = BossBar.bossBar(Msg.c(""), 0f, BossBar.Color.PURPLE, BossBar.Overlay.NOTCHED_10);
            bars.put(p.getUniqueId(), bar);
            p.showBossBar(bar);
        }
        bar.name(Msg.c("<gradient:#8a5cff:#ffd24d>Magic Essence</gradient> <white>" + ess + "<gray>/" + max));
        bar.progress(Math.max(0f, Math.min(1f, (float) ess / max)));
        bar.color(ess >= max ? BossBar.Color.YELLOW : BossBar.Color.PURPLE);
    }

    private void hideBar(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
    }
}
