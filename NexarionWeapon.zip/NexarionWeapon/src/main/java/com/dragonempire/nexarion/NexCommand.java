package com.dragonempire.nexarion;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;

public final class NexCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBS = List.of("help", "inspect", "give", "remove", "status", "essence", "reload", "test", "cooldowns");
    private final NexarionPlugin pl;

    public NexCommand(NexarionPlugin pl) {
        this.pl = pl;
    }

    private boolean perm(CommandSender s, String sub) {
        if (s.hasPermission("nexarion.admin." + sub)) return true;
        Msg.send(s, "<red>You lack permission <dark_gray>(nexarion.admin." + sub + ")");
        return false;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "inspect" -> {
                if (!(s instanceof Player p)) { Msg.send(s, "<red>Players only"); return true; }
                if (!p.hasPermission("nexarion.use")) { Msg.send(s, "<red>No permission"); return true; }
                pl.gui().open(p);
            }
            case "give" -> {
                if (!perm(s, "give")) return true;
                Player t = target(s, a, 1);
                if (t == null) return true;
                Form f = a.length > 2 ? Form.parse(a[2]) : Form.STAFF;
                if (f == null) { Msg.send(s, "<red>Form must be staff, sword or dagger"); return true; }
                ItemStack it = pl.items().create(f);
                var left = t.getInventory().addItem(it);
                left.values().forEach(i -> t.getWorld().dropItemNaturally(t.getLocation(), i));
                Msg.send(s, "Gave NEXARION (" + f.display + ") to <white>" + t.getName());
            }
            case "remove" -> {
                if (!perm(s, "remove")) return true;
                Player t = target(s, a, 1);
                if (t == null) return true;
                int n = 0;
                PlayerInventory inv = t.getInventory();
                for (int i = 0; i < inv.getSize(); i++) {
                    if (pl.items().isNexarion(inv.getItem(i))) { inv.setItem(i, null); n++; }
                }
                pl.effects().endAll(t.getUniqueId());
                Msg.send(s, "Removed <white>" + n + "<gray> NEXARION item(s) from <white>" + t.getName());
            }
            case "status" -> {
                if (!perm(s, "status")) return true;
                Player t = target(s, a, 1);
                if (t == null) return true;
                int n = 0;
                Form held = null;
                for (ItemStack i : t.getInventory().getContents()) if (pl.items().isNexarion(i)) n++;
                ItemStack main = t.getInventory().getItemInMainHand();
                if (pl.items().isNexarion(main)) held = pl.items().form(main);
                Msg.send(s, "<white>" + t.getName() + "<gray>: weapons <white>" + n + "<gray>, holding <white>"
                        + (held == null ? "none" : held.display) + "<gray>, essence <gold>" + pl.essence().get(t.getUniqueId())
                        + "<gray>/" + pl.essence().max() + ", active effects (server) <white>" + pl.effects().count());
            }
            case "essence" -> essence(s, a);
            case "reload" -> {
                if (!perm(s, "reload")) return true;
                pl.reloadAll();
                Msg.send(s, "Configuration reloaded. <dark_gray>(Existing weapons refresh stats when their form changes.)");
            }
            case "test" -> {
                if (!perm(s, "test")) return true;
                if (a.length < 2) { Msg.send(s, "<red>/nexarion test <ability> [player]"); return true; }
                Ability ab = Ability.parse(a[1]);
                if (ab == null) { Msg.send(s, "<red>Unknown ability. " + abilityNames()); return true; }
                Player t = target(s, a, 2);
                if (t == null) return true;
                boolean ok = pl.abilities().cast(t, ab, true);
                Msg.send(s, ab.display + (ok ? " <green>cast" : " <red>could not run") + "<gray> on <white>" + t.getName() + "<dark_gray> (cooldown/cost bypassed)");
            }
            case "cooldowns" -> {
                if (!perm(s, "cooldowns")) return true;
                Player t = target(s, a, 1);
                if (t == null) return true;
                StringBuilder sb = new StringBuilder("Cooldowns for <white>" + t.getName() + "<gray>:");
                for (Ability ab : Ability.values()) {
                    long r = pl.cooldowns().remainingMs(t.getUniqueId(), ab);
                    sb.append("\n <dark_gray>- <white>").append(ab.display).append("<gray>: ")
                            .append(r > 0 ? "<red>" + String.format("%.1fs", r / 1000.0) : "<green>ready");
                }
                Msg.send(s, sb.toString());
            }
            default -> help(s);
        }
        return true;
    }

    private void essence(CommandSender s, String[] a) {
        if (!perm(s, "essence")) return;
        if (a.length < 3) { Msg.send(s, "<red>/nexarion essence <get|set|add|reset> <player> [amount]"); return; }
        String op = a[1].toLowerCase(Locale.ROOT);
        UUID id;
        String name;
        Player online = Bukkit.getPlayerExact(a[2]);
        if (online != null) { id = online.getUniqueId(); name = online.getName(); }
        else {
            OfflinePlayer off = Bukkit.getOfflinePlayerIfCached(a[2]);
            if (off == null) { Msg.send(s, "<red>Unknown player " + a[2]); return; }
            id = off.getUniqueId(); name = off.getName() == null ? a[2] : off.getName();
        }
        switch (op) {
            case "get" -> Msg.send(s, "<white>" + name + "<gray> has <gold>" + pl.essence().get(id) + "<gray>/" + pl.essence().max() + " essence");
            case "reset" -> { pl.essence().reset(id); Msg.send(s, "Reset essence of <white>" + name); }
            case "set", "add" -> {
                if (a.length < 4) { Msg.send(s, "<red>Amount required"); return; }
                int n;
                try { n = Integer.parseInt(a[3]); } catch (NumberFormatException e) { Msg.send(s, "<red>Not a number"); return; }
                if (op.equals("set")) pl.essence().set(id, n); else pl.essence().add(id, n);
                Msg.send(s, "<white>" + name + "<gray> now has <gold>" + pl.essence().get(id) + " essence");
            }
            default -> Msg.send(s, "<red>Use get, set, add or reset");
        }
    }

    private Player target(CommandSender s, String[] a, int idx) {
        if (a.length > idx) {
            Player t = Bukkit.getPlayerExact(a[idx]);
            if (t == null) Msg.send(s, "<red>Player not online: " + a[idx]);
            return t;
        }
        if (s instanceof Player p) return p;
        Msg.send(s, "<red>Specify a player");
        return null;
    }

    private String abilityNames() {
        return Arrays.stream(Ability.values()).map(Ability::key).collect(Collectors.joining(", "));
    }

    private void help(CommandSender s) {
        Msg.send(s, "Commands:\n<white>/nexarion inspect <gray>- weapon & essence GUI"
                + "\n<white>/nexarion give <player> [staff|sword|dagger]"
                + "\n<white>/nexarion remove <player>"
                + "\n<white>/nexarion status [player]"
                + "\n<white>/nexarion essence <get|set|add|reset> <player> [n]"
                + "\n<white>/nexarion cooldowns [player]"
                + "\n<white>/nexarion test <ability> [player]"
                + "\n<white>/nexarion reload");
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.addAll(SUBS);
        else if (a.length == 2 && a[0].equalsIgnoreCase("essence")) out.addAll(List.of("get", "set", "add", "reset"));
        else if (a.length == 2 && a[0].equalsIgnoreCase("test")) for (Ability ab : Ability.values()) out.add(ab.key());
        else if (a.length == 3 && a[0].equalsIgnoreCase("give")) out.addAll(List.of("staff", "sword", "dagger"));
        else if ((a.length == 2 && List.of("give", "remove", "status", "cooldowns").contains(a[0].toLowerCase()))
                || (a.length == 3 && List.of("essence", "test").contains(a[0].toLowerCase())))
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        String last = a.length == 0 ? "" : a[a.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(last)).collect(Collectors.toList());
    }
}
