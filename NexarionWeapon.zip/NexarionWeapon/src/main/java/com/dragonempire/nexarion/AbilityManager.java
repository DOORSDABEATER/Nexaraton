package com.dragonempire.nexarion;

import com.dragonempire.nexarion.effects.Bolt;
import com.dragonempire.nexarion.effects.DomainExpansionEffect;
import com.dragonempire.nexarion.effects.GravityBendingEffect;
import com.dragonempire.nexarion.effects.InfinityEffect;
import com.dragonempire.nexarion.effects.LevitateEffect;
import com.dragonempire.nexarion.effects.SimpleDomainEffect;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/** Casting pipeline (permission, cooldown, essence) and every ability implementation. */
public final class AbilityManager {
    private final NexarionPlugin pl;

    public AbilityManager(NexarionPlugin pl) {
        this.pl = pl;
    }

    public long cooldownMs(Ability a) {
        return (long) (pl.getConfig().getDouble("abilities." + a.key() + ".cooldown", 5.0) * 1000);
    }

    public int cost(Ability a) {
        return pl.essence().cost(a.key());
    }

    // ------------------------------------------------------------ forms / selection

    public void cycle(Player p, ItemStack it) {
        Form f = pl.items().form(it);
        List<Ability> list = f.abilities();
        if (list.size() <= 1) {
            pl.hud().flash(p, "<gray>" + f.display + " has only <white>" + list.get(0).display);
            return;
        }
        int sel = (pl.items().selected(it) + 1) % list.size();
        pl.items().setSelected(it, sel);
        p.getInventory().setItemInMainHand(it);
        Ability a = list.get(sel);
        Fx.sound(p.getLocation(), "select", 0.6f, 0.9f + sel * 0.08f);
        pl.hud().flash(p, (a.ultimate ? "<gold>★ " : "<light_purple>▶ ") + "<white>" + a.display
                + " <dark_gray>(" + (sel + 1) + "/" + list.size() + ") <gray>cost <gold>" + cost(a) + " ✦");
    }

    public void switchForm(Player p, ItemStack it) {
        Form f = pl.items().form(it);
        setForm(p, it, f == Form.STAFF ? Form.SWORD : Form.STAFF);
    }

    public void toggleDagger(Player p, ItemStack it) {
        Form f = pl.items().form(it);
        if (f == Form.STAFF) {
            pl.hud().flash(p, "<red>Dagger Submode needs Sword Form");
            return;
        }
        setForm(p, it, f == Form.SWORD ? Form.DAGGER : Form.SWORD);
    }

    private void setForm(Player p, ItemStack it, Form to) {
        pl.items().apply(it, to, 0);
        p.getInventory().setItemInMainHand(it);
        Color c = switch (to) {
            case STAFF -> Fx.VIOLET;
            case SWORD -> Fx.GOLD;
            case DAGGER -> Fx.CRIMSON;
        };
        Location l = p.getLocation().add(0, 1, 0);
        Fx.sound(l, "transform", 1f, 1f);
        for (int i = 0; i < 40; i++) {
            double a = i * 0.5;
            Fx.dust(l.clone().add(Math.cos(a) * 0.9, i * 0.05 - 1.0, Math.sin(a) * 0.9), c, 1.2f, 1, 0.02);
        }
        Fx.p(l, Particle.END_ROD, 12, 0.4, 0.6, 0.4, 0.05);
        pl.hud().flash(p, "<gradient:#8a5cff:#ffd24d><b>" + to.display + " Form</b></gradient>");
    }

    public void activateSelected(Player p, ItemStack it) {
        Form f = pl.items().form(it);
        List<Ability> list = f.abilities();
        int sel = Math.min(pl.items().selected(it), list.size() - 1);
        Ability a = list.get(Math.max(0, sel));
        UUID id = p.getUniqueId();
        if (a == Ability.GRAVITY_BENDING) {
            GravityBendingEffect g = pl.effects().find(id, GravityBendingEffect.class);
            if (g != null) {
                g.nextMode();
                return;
            }
        }
        cast(p, a, false);
    }

    public void throwDagger(Player p) {
        cast(p, Ability.DAGGER_THROW, false);
    }

    // ------------------------------------------------------------------- casting

    public boolean cast(Player p, Ability ab, boolean force) {
        UUID id = p.getUniqueId();
        if (!force) {
            if (!p.hasPermission("nexarion.use")) return false;
            long rem = pl.cooldowns().remainingMs(id, ab);
            if (rem > 0) {
                if (ab != Ability.DAGGER_THROW) {
                    pl.hud().flash(p, "<red>" + ab.display + " <gray>recharging <white>" + String.format("%.1f", rem / 1000.0) + "s");
                }
                return false;
            }
            int cost = cost(ab);
            if (pl.essence().get(id) < cost) {
                pl.hud().flash(p, "<red>Not enough Essence <gray>(" + cost + " ✦ needed)");
                Fx.sound(p.getLocation(), "deny", 0.5f, 1f);
                return false;
            }
        }
        boolean ok;
        try {
            ok = run(p, ab);
        } catch (Throwable ex) {
            pl.getLogger().log(Level.WARNING, "Ability " + ab + " failed", ex);
            ok = false;
        }
        if (ok && !force) {
            pl.essence().consume(p, cost(ab));
            pl.cooldowns().set(id, ab, cooldownMs(ab));
        }
        return ok;
    }

    private boolean run(Player p, Ability ab) {
        return switch (ab) {
            case AIR_SLASH -> airSlash(p);
            case FIREBALL -> fireball(p);
            case LEVITATE -> levitate(p);
            case SIMPLE_DOMAIN -> sustained(p, SimpleDomainEffect.class, new SimpleDomainEffect(pl, p), 2, "Simple Domain");
            case INFINITY -> sustained(p, InfinityEffect.class, new InfinityEffect(pl, p), 2, "Infinity");
            case DOMAIN_EXPANSION -> sustained(p, DomainExpansionEffect.class, new DomainExpansionEffect(pl, p), 2, "Domain Expansion");
            case GRAVITY_BENDING -> gravity(p);
            case DAGGER_THROW -> dagger(p);
        };
    }

    private <T extends com.dragonempire.nexarion.effects.Effect> boolean sustained(Player p, Class<T> type, T effect, long period, String name) {
        if (pl.effects().find(p.getUniqueId(), type) != null) {
            pl.hud().flash(p, "<gray>" + name + " is already active");
            return false;
        }
        effect.start(period);
        return true;
    }

    // ---------------------------------------------------------------- Air Slash

    private boolean airSlash(Player p) {
        FileConfiguration c = pl.getConfig();
        double dmg = c.getDouble("abilities.air_slash.damage", 6.0);
        double range = c.getDouble("abilities.air_slash.range", 28.0);
        double speed = c.getDouble("abilities.air_slash.speed", 1.6);
        int pierce = c.getInt("abilities.air_slash.pierce", 3);
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        Location start = eye.clone().add(dir.clone().multiply(1.0));

        Vector right = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (right.lengthSquared() < 1e-4) right = new Vector(1, 0, 0);
        right.normalize();
        Vector up = right.clone().crossProduct(dir).normalize();
        double roll = Math.random() * Math.PI - Math.PI / 2;
        Vector rr = right.clone().multiply(Math.cos(roll)).add(up.clone().multiply(Math.sin(roll)));

        Fx.sound(p.getLocation(), "air_slash", 1f, 0.9f + (float) Math.random() * 0.2f);
        Fx.slashDisplay(start, dir, (float) roll, 2.6f, 6);

        Bolt b = new Bolt(pl, p, start, dir, speed, range, 0.9, pierce);
        final Vector rrF = rr;
        b.onStep = (bolt, pos) -> {
            for (int i = -4; i <= 4; i++) {
                double ang = i * 0.2;
                Location q = pos.clone().add(rrF.clone().multiply(Math.sin(ang) * 1.5)).subtract(dir.clone().multiply((1 - Math.cos(ang)) * 0.9));
                Fx.dust(q, (i % 2 == 0) ? Fx.LILAC : Fx.WHITE, 1.0f, 1, 0.0);
            }
            Fx.p(pos, Particle.CLOUD, 1, 0.15, 0.15, 0.15, 0.0);
            Fx.p(pos, Particle.ELECTRIC_SPARK, 1, 0.5, 0.5, 0.5, 0.0);
        };
        b.onEntity = (bolt, e, pos) -> {
            if (Dmg.hit(pl, p, e, dmg, "air_slash")) {
                e.setVelocity(e.getVelocity().add(dir.clone().multiply(0.45).setY(0.18)));
            }
            Location at = e.getLocation().add(0, e.getHeight() * 0.5, 0);
            Fx.p(at, Particle.SWEEP_ATTACK, 1, 0, 0, 0, 0);
            Fx.p(at, Particle.CRIT, 10, 0.3, 0.3, 0.3, 0.3);
            Fx.sound(at, "air_slash_hit", 0.8f, 1f);
        };
        b.onBlock = (bolt, pos) -> Fx.p(pos, Particle.ENCHANTED_HIT, 8, 0.2, 0.2, 0.2, 0.2);
        b.start(1);
        return true;
    }

    // ----------------------------------------------------------------- Fireball

    private boolean fireball(Player p) {
        FileConfiguration c = pl.getConfig();
        double speed = c.getDouble("abilities.fireball.speed", 1.2);
        double range = c.getDouble("abilities.fireball.range", 45.0);
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        Location start = eye.clone().add(dir.clone().multiply(1.2));

        Fx.sound(p.getLocation(), "fireball_cast", 1f, 1f);
        Bolt b = new Bolt(pl, p, start, dir, speed, range, 0.8, 0);
        b.display = Fx.itemDisplay(start, Material.PAPER, "fireball", 1.3f, true);
        b.onStep = (bolt, pos) -> {
            Fx.p(pos, Particle.FLAME, 2, 0.15, 0.15, 0.15, 0.01);
            Fx.p(pos, Particle.SOUL_FIRE_FLAME, 1, 0.1, 0.1, 0.1, 0.01);
            Fx.dust(pos, Fx.ORANGE, 1.4f, 2, 0.15);
            if (Math.random() < 0.3) Fx.p(pos, Particle.SMOKE, 1, 0.1, 0.1, 0.1, 0.0);
        };
        b.onEnd = () -> explode(p, b.pos.clone());
        b.start(1);
        return true;
    }

    private void explode(Player p, Location loc) {
        FileConfiguration c = pl.getConfig();
        double r = c.getDouble("abilities.fireball.blast-radius", 4.0);
        double dmg = c.getDouble("abilities.fireball.damage", 9.0);
        double kb = c.getDouble("abilities.fireball.knockback", 1.1);
        int ignite = c.getInt("abilities.fireball.ignite-seconds", 3);
        World w = loc.getWorld();
        Fx.p(loc, Particle.EXPLOSION, 2, 0.4, 0.4, 0.4, 0.0);
        Fx.p(loc, Particle.FLAME, 70, r * 0.3, r * 0.3, r * 0.3, 0.12);
        Fx.p(loc, Particle.SOUL_FIRE_FLAME, 30, r * 0.25, r * 0.25, r * 0.25, 0.08);
        Fx.p(loc, Particle.LAVA, 12, r * 0.3, r * 0.3, r * 0.3, 0.0);
        Fx.ring(loc, r * 0.8, 30, 0, Fx.ORANGE, 1.5f);
        Fx.sound(loc, "fireball_explode", 1.4f, 1f);
        for (Entity e : w.getNearbyEntities(loc, r, r, r)) {
            if (!(e instanceof LivingEntity le) || !Dmg.eligible(pl, p, le)) continue;
            double d = le.getLocation().add(0, le.getHeight() * 0.5, 0).distance(loc);
            if (d > r) continue;
            double falloff = 1.0 - 0.5 * (d / r);
            Vector away = le.getLocation().add(0, 0.5, 0).toVector().subtract(loc.toVector());
            if (away.lengthSquared() < 0.01) away = new Vector(0, 1, 0);
            if (Dmg.hit(pl, p, le, dmg * falloff, "fireball")) {
                le.setVelocity(le.getVelocity().add(away.normalize().multiply(kb * falloff).setY(0.35)));
                if (ignite > 0) le.setFireTicks(Math.max(le.getFireTicks(), ignite * 20));
            }
        }
    }

    // ----------------------------------------------------------------- Levitate

    private boolean levitate(Player p) {
        FileConfiguration c = pl.getConfig();
        UUID id = p.getUniqueId();
        LevitateEffect existing = pl.effects().find(id, LevitateEffect.class);
        if (existing != null && existing.isSelf()) {
            existing.end(); // recasting ends your own levitation, free of charge
            return false;
        }
        double range = c.getDouble("abilities.levitate.range", 20.0);
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.6,
                en -> !en.equals(p) && Dmg.controllable(pl, p, en, null));
        LivingEntity target = null;
        if (r != null && r.getHitEntity() instanceof LivingEntity le) target = le;
        if (target != null) {
            int ticks = (int) (c.getDouble("abilities.levitate.target-duration", 6.0) * 20);
            new LevitateEffect(pl, p, target, ticks, c.getDouble("abilities.levitate.target-height", 4.0)).start(1);
            Fx.sound(target.getLocation(), "levitate", 1f, 1.1f);
            Fx.line(eye.clone().add(eye.getDirection()), target.getLocation().add(0, 1, 0), Fx.LILAC, 1.0f, 0.4);
        } else {
            int ticks = (int) (c.getDouble("abilities.levitate.self-duration", 6.0) * 20);
            new LevitateEffect(pl, p, p, ticks, c.getDouble("abilities.levitate.self-height", 6.0)).start(1);
            Fx.sound(p.getLocation(), "levitate", 1f, 1f);
        }
        return true;
    }

    // ----------------------------------------------------------- Gravity Bending

    private boolean gravity(Player p) {
        FileConfiguration c = pl.getConfig();
        double range = c.getDouble("abilities.gravity_bending.range", 25.0);
        Location eye = p.getEyeLocation();
        RayTraceResult br = p.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        Location center = br != null ? br.getHitPosition().toLocation(p.getWorld()) : p.getLocation();
        new GravityBendingEffect(pl, p, center).start(1);
        return true;
    }

    // ------------------------------------------------------------------- Daggers

    private boolean dagger(Player p) {
        FileConfiguration c = pl.getConfig();
        double dmg = c.getDouble("abilities.dagger_throw.damage", 5.0);
        double range = c.getDouble("abilities.dagger_throw.range", 32.0);
        double speed = c.getDouble("abilities.dagger_throw.speed", 1.8);
        int count = Math.max(1, Math.min(7, c.getInt("abilities.dagger_throw.count", 3)));
        double spread = Math.toRadians(c.getDouble("abilities.dagger_throw.spread-degrees", 7.0));
        Location eye = p.getEyeLocation();
        Vector base = eye.getDirection().normalize();
        Fx.sound(p.getLocation(), "dagger_throw", 1f, 0.95f + (float) Math.random() * 0.1f);
        for (int i = 0; i < count; i++) {
            double off = (i - (count - 1) / 2.0) * spread;
            Vector dir = base.clone().rotateAroundY(off).normalize();
            Location start = eye.clone().add(dir.clone().multiply(0.9));
            Bolt b = new Bolt(pl, p, start, dir, speed, range, 0.6, 0);
            b.display = Fx.itemDisplay(start, Material.PAPER, "dagger_projectile", 0.9f, false);
            b.spin = 0.6f;
            b.displayScale = 0.9f;
            b.onStep = (bolt, pos) -> {
                Fx.dust(pos, Fx.CRIMSON, 0.9f, 1, 0.02);
                if (Math.random() < 0.4) Fx.p(pos, Particle.CRIT, 1, 0.05, 0.05, 0.05, 0.0);
            };
            b.onEntity = (bolt, e, pos) -> {
                Dmg.hit(pl, p, e, dmg, "dagger_throw");
                Location at = e.getLocation().add(0, e.getHeight() * 0.5, 0);
                Fx.p(at, Particle.CRIT, 8, 0.2, 0.2, 0.2, 0.25);
                Fx.sound(at, "dagger_hit", 0.8f, 1f);
            };
            b.onBlock = (bolt, pos) -> {
                Fx.p(pos, Particle.ELECTRIC_SPARK, 8, 0.1, 0.1, 0.1, 0.3);
                Fx.sound(pos, "dagger_hit", 0.5f, 1.4f);
            };
            b.start(1);
        }
        return true;
    }
}
