package com.dragonempire.nexarion;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Read-only weapon inspection interface. */
public final class InspectGui implements InventoryHolder, Listener {
    private final NexarionPlugin pl;
    private Inventory inv;

    public InspectGui(NexarionPlugin pl) {
        this.pl = pl;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    public void open(Player p) {
        InspectGui holder = new InspectGui(pl);
        holder.inv = Bukkit.createInventory(holder, 27, Msg.c("<gradient:#8a5cff:#ffd24d><b>NEXARION</b></gradient> <dark_gray>Inspection"));
        UUID id = p.getUniqueId();
        int ess = pl.essence().get(id), max = pl.essence().max();

        ItemStack held = p.getInventory().getItemInMainHand();
        Form f = pl.items().isNexarion(held) ? pl.items().form(held) : Form.STAFF;
        holder.inv.setItem(4, icon(Material.EXPERIENCE_BOTTLE, "<gradient:#8a5cff:#ffd24d>Magic Essence</gradient>",
                "<gray>" + ess + " / " + max, bar(ess, max), "<dark_gray>Earned by dealing ability damage"));

        Ability[] abs = {Ability.AIR_SLASH, Ability.FIREBALL, Ability.LEVITATE, Ability.SIMPLE_DOMAIN,
                Ability.INFINITY, Ability.DOMAIN_EXPANSION, Ability.GRAVITY_BENDING};
        Material[] mats = {Material.FEATHER, Material.FIRE_CHARGE, Material.SHULKER_SHELL, Material.IRON_SWORD,
                Material.ENDER_EYE, Material.NETHER_STAR, Material.ECHO_SHARD};
        for (int i = 0; i < abs.length; i++) {
            Ability a = abs[i];
            long rem = pl.cooldowns().remainingMs(id, a);
            int cost = pl.abilities().cost(a);
            String status = rem > 0 ? "<red>Recharging " + String.format("%.1fs", rem / 1000.0)
                    : ess < cost ? "<red>Needs " + cost + " essence" : "<green>Ready";
            holder.inv.setItem(10 + i, icon(mats[i], (a.ultimate ? "<gold>★ " : "<light_purple>◆ ") + "<white>" + a.display,
                    "<gray>Cost: <gold>" + cost + " ✦", "<gray>Cooldown: <white>" + (a == Ability.GRAVITY_BENDING
                            ? String.format("%.0fs", pl.abilities().cooldownMs(a) / 1000.0) + " <dark_gray>(lasts exactly 60s)"
                            : String.format("%.0fs", pl.abilities().cooldownMs(a) / 1000.0)), status));
        }
        holder.inv.setItem(22, icon(Material.BOOK, "<white>Controls",
                "<gray>Right Click: <white>use selected ability",
                "<gray>Shift + Left Click: <white>cycle ability",
                "<gray>Shift + Right Click: <white>Staff ⇄ Sword",
                "<gray>Shift + F: <white>Sword ⇄ Dagger Submode",
                "<gray>Dagger Submode, Shift + Left Click: <white>throw daggers",
                "<dark_gray>Current form: " + f.display));
        p.openInventory(holder.inv);
    }

    private static String bar(int v, int max) {
        int filled = Math.round(20f * v / max);
        return "<light_purple>" + "█".repeat(filled) + "<dark_gray>" + "█".repeat(20 - filled);
    }

    private static ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Msg.c("<!italic>" + name));
        List<net.kyori.adventure.text.Component> l = new ArrayList<>();
        for (String s : lore) l.add(Msg.c("<!italic>" + s));
        meta.lore(l);
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (e.getInventory().getHolder(false) instanceof InspectGui) e.setCancelled(true);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof InspectGui) e.setCancelled(true);
    }
}
