# NEXARION - The Boundless Sovereign
Add-on plugin for Dragon Empire SMP (Paper 1.21.4+, Java 21). Runs beside DeSWeaponExpansion without touching it
(own command `/nexarion`, own data keys, own config folder; DeS is only a soft-dependency for load order).

## Build
Requires JDK 21 and Gradle 8.x (the GitHub Actions workflow does this for you).

    gradle build          # -> build/libs/NexarionWeapon-1.0.0.jar

CI: `.github/workflows/build.yml` compiles, verifies the JAR, and uploads two artifacts
(`NexarionWeapon-plugin`, `NEXARION-ResourcePack`). A failing build uploads nothing and prints an error summary.

## Install
1. Put the JAR in `plugins/`, start the server, edit `plugins/NexarionWeapon/config.yml`.
2. Install the resource pack (see docs/RESOURCEPACK.md). Without it the weapon is a netherite sword with
   particles; set `sounds.mode: vanilla` if you want sounds without the pack.
3. `/nexarion give <player>`.

## Controls (all rebindable in config `controls:`)
| Input | Action |
|---|---|
| Right click | Use selected ability |
| Shift + Left click | Cycle ability (Dagger Submode: throw daggers instead) |
| Shift + Right click | Staff <-> Sword |
| Shift + F | Sword <-> Dagger Submode |
| Left click | Melee |

Shift+Left click on an adjacent mob is intercepted too, so cycling/throwing works at melee range.

## Design notes
- Identity: HMAC-signed persistent tag (key in `secret.key`), so renamed items are never NEXARION.
- Essence: earned only from damage that actually lowered a target's health (region/PvP vetoes give nothing),
  per-target/minute/hour caps, persisted in `essence.yml` (atomic write).
- Damage uses the normal damage pipeline, so WorldGuard-style protection applies. No block is ever changed:
  the Domain's terrain is client-side only and restored on end/logout/death/shutdown.
- Gravity Bending lasts exactly 1200 ticks (fixed, not configurable). Movement effects are 12-tick potions that are
  refreshed, plus a gravity registry with chunk-unload and crash repair, so nothing can stay permanent.
- Targeting: `targeting:` in config (players need world PvP on; passive mobs, pets, villagers off by default).

## Known limits
- Sounds are layered, pitch-shifted vanilla events (no custom audio files). Drop real `.ogg` files in and point
  `sounds.json` at them for a bespoke sound design.
- Models/textures are procedural and were not viewed in-game; tune display transforms in Blockbench.
- Attack "animations" are slash sprites and particles; vanilla swing animation is unchanged.
