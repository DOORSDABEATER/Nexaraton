# Commands (`/nexarion`, alias `/nex`)
| Command | Permission | Effect |
|---|---|---|
| `/nexarion inspect` | nexarion.use | Open the inspection GUI (essence, costs, cooldowns, controls) |
| `/nexarion give <player> [staff\|sword\|dagger]` | nexarion.admin.give | Give NEXARION |
| `/nexarion remove <player>` | nexarion.admin.remove | Remove all NEXARION items, end their effects |
| `/nexarion status [player]` | nexarion.admin.status | Weapons held, form, essence |
| `/nexarion essence get\|set\|add\|reset <player> [n]` | nexarion.admin.essence | Inspect / modify essence (works for cached offline players) |
| `/nexarion cooldowns [player]` | nexarion.admin.cooldowns | Remaining cooldowns |
| `/nexarion test <ability> [player]` | nexarion.admin.test | Cast ignoring cost and cooldown. Abilities: air_slash, fireball, levitate, simple_domain, infinity, domain_expansion, gravity_bending, dagger_throw |
| `/nexarion reload` | nexarion.admin.reload | Reload config and controls |

`nexarion.admin` (default op) grants all admin subcommands; `nexarion.use` defaults to everyone.
