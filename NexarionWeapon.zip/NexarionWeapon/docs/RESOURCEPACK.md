# Resource pack
Built from `resourcepack/` (CI uploads `NEXARION-ResourcePack.zip` + `.sha1`). Targets Minecraft 1.21.4-1.21.x
(`pack_format` 46, item definitions in `assets/nexarion/items/`). Newer clients/servers may need `pack.mcmeta` updated.

## Install on the server
1. Host the zip at a direct HTTPS URL.
2. `server.properties`: `resource-pack=<url>`, `resource-pack-sha1=<contents of the .sha1 file>`,
   optionally `require-resource-pack=true`.
3. Players can also drop the zip in `.minecraft/resourcepacks`.

## Contents
- `items/` + `models/item/`: staff, sword, dagger, dagger projectile, slash arc, fireball sprite, essence orb
  (one shared 32x32 atlas for the 3D weapons; total pack ~150 KB).
- `sounds.json`: 24 `nexarion:*` events for every ability, transformation, essence and equip.
- All assets are original; no third-party textures or audio are included.
